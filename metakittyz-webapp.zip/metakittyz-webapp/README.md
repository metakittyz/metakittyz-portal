# MetaKittyz Portal -- Standalone Web App

This is the MetaKittyz AI orchestration dashboard (NOVA, ARIA, GUARDIAN, PULSE, REACH, SPARK, Growth Engine, Content
Studio, Media Coach) ported out of the Claude.ai artifact sandbox into a real, deployable web app.

**Why this exists:** inside Claude.ai, artifacts run in a sandboxed iframe that blocks camera access and handles the
Claude API connection invisibly. Outside that sandbox, both of those need to be handled explicitly -- that's what
the two serverless functions in `api/` are for, and it's also what makes the camera in Media Coach actually work.

---

## 1. Prerequisites

- [Node.js](https://nodejs.org/) 18 or newer installed
- A free [Vercel](https://vercel.com/) account (used for hosting + the serverless functions)
- An [Anthropic API key](https://console.anthropic.com/) (this is a **paid API key**, separate from a claude.ai
  subscription -- it bills per API call)
- VS Code (or any editor) -- to open the project after unzipping

---

## 2. Open the project in VS Code

1. Unzip the downloaded file
2. Open VS Code
3. `File > Open Folder...` and select the unzipped `metakittyz-webapp` folder
   (or, from a terminal inside the folder, just run `code .`)

---

## 3. Install dependencies

In a terminal, inside the project folder:

```bash
npm install
```

---

## 4. Set up your Anthropic API key

```bash
cp .env.example .env
```

Open the new `.env` file and paste your real key in place of the placeholder:

```
ANTHROPIC_API_KEY=sk-ant-...
```

This file is already in `.gitignore` -- it will not be committed if you push this to GitHub.

---

## 5. Run it locally

This project needs its serverless functions (`api/claude.js`, `api/openai-tts.js`) running alongside the frontend,
so plain `vite dev` alone won't wire those up. Use the Vercel CLI instead, which emulates them locally:

```bash
npm install -g vercel   # one-time global install
vercel dev
```

It will ask a few setup questions the first time (link to a Vercel account/project -- you can create a new project
right from the prompt). Once running, it prints a local URL (typically `http://localhost:3000`). Open that in your
browser.

Camera access, chat with the agents, Growth Engine, Content Studio, and Media Coach should all work at this point.

---

## 6. Deploy it for real

```bash
vercel
```

Follow the prompts (same as `vercel dev`, first run links/creates a project). After it deploys, **set your API key
on the live project too** -- local `.env` files don't travel with the deployment:

```bash
vercel env add ANTHROPIC_API_KEY
```

Paste your key when prompted, choose "Production" (and "Preview"/"Development" too if you want those to work as
well), then redeploy:

```bash
vercel --prod
```

You'll get a real `https://...vercel.app` URL. Because it's a real HTTPS site (not an iframe), camera permission
prompts work exactly like any normal website.

---

## 7. About the OpenAI voice (optional)

Media Coach and agent chat can use OpenAI's TTS for a warmer voice. This is "bring your own key" -- there's a Voice
Settings panel in the app itself where you paste an OpenAI key. That key is sent to `/api/openai-tts` (the proxy in
this project) on each request rather than stored anywhere permanent -- it exists only in that browser's memory/local
storage for that session. It's still visible in that browser's own Network tab if dev tools are open, same as any
client-entered key, so don't paste it in on a shared screen with dev tools open.

If you skip this, the app falls back automatically to the browser's built-in voice -- no OpenAI key required.

---

## 8. Data storage -- one important limitation

This app persists its data (chats, metrics, content calendar, revenue log, etc.) using **your browser's
localStorage**, polyfilled to match the same interface the Claude.ai artifact used (see
`src/storage-polyfill.js`). That means:

- Data stays on the device/browser you're using -- it does **not** sync across devices or between different visitors
- Clearing your browser's site data for this URL will clear the dashboard's data too
- If you eventually want real multi-device or multi-user data, that requires an actual backend database (e.g.
  Postgres via Vercel Postgres, Supabase, etc.) -- that's a further build, not included here

---

## 9. Project structure

```
metakittyz-webapp/
  api/
    claude.js         <- serverless proxy to Anthropic's API (keeps your key server-side)
    openai-tts.js     <- serverless proxy to OpenAI's TTS API (works around OpenAI's CORS block)
  src/
    App.jsx           <- the entire dashboard (agents, Growth Engine, Content Studio, Media Coach, etc.)
    main.jsx           <- React entry point
    storage-polyfill.js <- localStorage shim matching the artifact's storage API
  index.html
  package.json
  vite.config.js
  .env.example
```
