// Polyfills the `window.storage` API that Claude.ai artifacts provide natively,
// backed by this browser's localStorage instead. This means App.jsx (ported directly
// from the artifact) needs no code changes for its storage calls.
//
// LIMITATION: this is per-browser, local-only storage -- there is no real backend
// database here, so data does not sync across devices or between different users.
// The `shared` flag from the original API is accepted for interface compatibility
// but has no special meaning here (everything is local to this browser).

const PREFIX = "mkz_storage:";

function readAll() {
  const out = {};
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith(PREFIX)) {
      out[k.slice(PREFIX.length)] = localStorage.getItem(k);
    }
  }
  return out;
}

window.storage = {
  async get(key) {
    const raw = localStorage.getItem(PREFIX + key);
    if (raw === null) return null;
    return { key, value: raw, shared: false };
  },

  async set(key, value) {
    localStorage.setItem(PREFIX + key, value);
    return { key, value, shared: false };
  },

  async delete(key) {
    const existed = localStorage.getItem(PREFIX + key) !== null;
    localStorage.removeItem(PREFIX + key);
    return { key, deleted: existed, shared: false };
  },

  async list(prefix) {
    const all = readAll();
    const keys = Object.keys(all).filter((k) => !prefix || k.startsWith(prefix));
    return { keys, prefix, shared: false };
  },
};
