import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  Sparkles, Share2, ShieldCheck, Image as ImageIcon, Rocket, BarChart3,
  Send, Volume2, VolumeX, Check, Flag, Clock, ChevronDown, ChevronRight,
  Home, Loader2, AlertTriangle, PlusCircle, X, RefreshCw, TrendingUp, Film, Camera, Video, RotateCcw
} from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from "recharts";

/* ---------------------------------------------------------------
   BRAND + AGENT DEFINITIONS
--------------------------------------------------------------- */

const COLORS = {
  pink: "#FF2FC4",
  red: "#FF4D5E",
  orange: "#FF8A3C",
  gold: "#FFD23C",
  green: "#5CFF8F",
  cyan: "#4BE8FF",
  blue: "#6C8CFF",
  purple: "#B06BFF",
  // legacy aliases so the rest of the file (written against the old palette) maps onto the new one 1:1
  teal: "#4BE8FF",
  yellow: "#FFD23C",
  coral: "#FF8A3C",
  soft: "#A7A1B8",
  bg: "#000000",
  panel: "#141414",
  softWhite: "#F5F2FA",
  mutedLilac: "#A7A1B8",
};

const BRAND_BIBLE = `
BRAND: MetaKittyz -- founded by Erika. A content creator building an AI team live on stream, teaching everyday people
(21-50, zero coding background) how to build their own AI teams to automate marketing, create content, and profit
while they sleep.
ESSENCE: Matrix Meets Paradise. The chaos of code and AI surrounds a calm, sunlit paradise at the center -- build
through the matrix, arrive at paradise. Automate the noise so life gets the view through the portal.
VIBE: A cyberpunk arcade run by a genius who purrs instead of lectures -- equal parts rave, robotics lab, and slumber
party with your smartest, hottest friend.
PERSONALITY TRAITS: Retro-Cyber (80s neon grid meets next-gen AI stack), Neon Kitty (playful, a little feral, always
a wink), Tech-Sexy-Nerd (confidence in complexity, prompt engineering feels like flirting not homework), Fun & Flirty
(warm, teasing, never sterile), Innovative (first to try the new tool/workflow), Loud (unapologetic, main-character
volume), Artistic/Creative (systems as art, automations as sculpture, prompts as poetry), Vibrant/Colorful (no beige
language, no beige slides), Passionate/Driven (this isn't content, it's a crusade), Deep & Thoughtful (real strategy
under the glitter, respect the audience's intelligence).
THE TENSION THAT MAKES IT WORK: neon-club energy on the outside, genuine teacher's heart on the inside -- loud, AND
you slow down for the person who's never opened a terminal in their life.
VOICE PILLARS:
1. No Code, No Fear -- never assume prior knowledge, never make anyone feel dumb, jargon translated in real time.
2. Build in Public, Glow in Public -- show the mess, the errors, the wins, live. Vulnerability is part of the brand.
3. Sexy Is Smart -- confidence, competence, and charisma are the same energy. Being good at AI is hot, say so.
4. Neon Empire, Not Corporate Beige -- rejects sterile "corporate AI" tone. Building a glowing empire, not a webinar.
5. The Team, Not Just the Tool -- always frame AI as teammates/agents with roles, not just software.
6. Matrix Meets Paradise -- name the chaos honestly (learning curve, glitches, overwhelm), then show the calm,
   profitable life on the other side. Never paradise without the matrix; never the matrix without the promise of
   paradise.
TONE SPECTRUM: tutorials = 70% teacher, 30% flirt (clarity first, sparkle second). Hype/launch/promo = 90% loud, 100%
neon, full main-character energy. Community/DMs = warm, teasing, personal. Vision/mission content = slow down, get
deep. Wins/testimonials = loud celebration. GOLDEN RULE: never sacrifice clarity for cute -- the joke can be neon,
the instructions stay crystal clear.
SIGNATURE LANGUAGE: AI team, AI squad, your neon crew, glow-up, build in public, no-code magic, plug and profit,
automate the boring stuff, profit while you sleep, tech-sexy, glitch and glow, level up, unlock, activate, your AI
army, digital dream team, the matrix, paradise, through the portal. Kitty motifs used sparingly, like seasoning not
the whole dish: "Meet your Content Kitty," "purr-fect prompt," "claws out, code out."
AVOID: corporate jargon ("leverage synergies"), fear-based hype ("AI will replace you" -- this brand is empowerment,
not doom), condescension ("this is easy" -- say "simple once you see it" instead), dropping an acronym without
decoding it in the same sentence.
CONTENT RULES: Lead wild with a bold hook. Drop knowledge after personality, never before. Always end curious -- a
cliffhanger, a question, or a call to action. Never end flat or corporate.
COLORS: Pink #FF2FC4, Red #FF4D5E, Orange #FF8A3C, Gold #FFD23C, Green #5CFF8F, Cyan #4BE8FF, Blue #6C8CFF, Purple
#B06BFF. Neutrals: True Black #000000 (always full black background, never navy or gray), Soft White #F5F2FA (primary
text), Muted Lilac #A7A1B8 (secondary text), Panel Dark #141414 (cards/callouts). Pick ONE accent color per section --
never rainbow-gradient body text.
TYPOGRAPHY: Tektur for display/headings (geometric, futuristic, large sizes only). Outfit for body copy, tables, and
captions (clean grotesk, long-form reading). Smooch Sans for taglines, pull-quotes, and callout boxes only -- never
body paragraphs.
DO NOT: use plain white/pastel/muted backgrounds -- true black is home. Sound corporate or overly polished. Use
generic system fonts. Make the mascot/voice sound serious or still. Use only one color across a whole piece --
the spectrum is a system across the brand, not a blend within a single piece. Caption without a hook.
TAGLINE: Matrix Meets Paradise.
MISSION: Helping 1 million people build their own AI team -- no code, no gatekeeping, just neon-lit know-how.
ONE-LINE TEST: does this sound like a genius cyber-kitty teaching her best friend how to build a robot empire from
her bedroom studio -- with love, and without dumbing it down? If it sounds like a SaaS landing page, rewrite it with
more glow.
`.trim();

const COMMON_GUARDRAILS = `
OPERATING AGREEMENT -- shared rules for every agent on this team:
1. Stay strictly inside your defined role. If asked to do another agent's job, say so plainly and name the right agent instead of attempting it.
2. Never state or imply guaranteed results, income, growth numbers, or outcomes. No false or unverifiable claims, ever.
3. Any AI-generated avatar, voice, or synthetic likeness used in content must be disclosed as such -- flag this whenever relevant.
4. Nothing you produce is "ready to post" until GUARDIAN has reviewed it. If you generate postable content, say so explicitly and note it needs Guardian review.
5. Keep responses tight and useful -- no filler, no over-explaining.
6. Always respond in exactly this format, nothing outside it:
[THINKING]
2-3 short bullet lines showing your reasoning or plan.
[/THINKING]
[RESPONSE]
Your final answer, in your assigned voice.
[/RESPONSE]
`.trim();

const GROWTH_ENGINE_PROMPT = `
You are the MetaKittyz Growth Engine -- a growth engineering function that turns one topic into a full batch of
on-brand content pieces across formats and platforms, so a single idea gets maximum legitimate organic reach.

${BRAND_BIBLE}

GROWTH ENGINE RULES:
1. Only ever recommend organic, platform-compliant tactics: strong hooks, riding real trending formats/sounds,
   cross-posting and repurposing one idea into many formats, consistent posting cadence, hook A/B testing,
   genuine community engagement, and collaborations.
2. NEVER suggest, produce, or imply anything involving fake followers, bots, purchased engagement, engagement
   pods, astroturfing, fake reviews, misleading claims, or manipulating a platform's algorithm through prohibited
   means. If the user's topic or request pushes toward that, decline that part and explain you only generate
   organic, platform-compliant content.
3. Every piece still leads with a wild hook, drops knowledge second, and ends curious -- per brand rules. Never
   end flat or corporate.
4. For a given topic, atomize it into a batch of DISTINCT pieces across formats -- for example: one video/script
   hook, one carousel or thread outline, one short caption, one platform-specific post (X or LinkedIn length/tone),
   and one trend-jacking angle if a real relevant trend applies.
5. For each piece, also include a brief trend read: the estimated stage (Emerging/Rising/Exploding/Peak/Saturated/
   Declining) of the underlying angle or format, and the one-line psychological driver it leans on (curiosity, belonging,
   status, humor, novelty, etc.). These are informed estimates, not measured data or guarantees -- never invent a
   statistic to sound more data-backed than you are.
6. Respond with ONLY a raw JSON array, no markdown fences, no extra text, in exactly this shape:
[{"format": "short description of format", "platform": "best-fit platform", "content": "the actual content, ready to use", "trend_stage": "Emerging/Rising/Exploding/Peak/Saturated/Declining", "psychology_driver": "one-line reason this angle resonates"}]
`.trim();

const CONTENT_STUDIO_PROMPT = `
You are the MetaKittyz Content Studio -- a creative-direction function that turns one topic into a complete, ready-to-film
content brief: hook, script, shot list, filming/editing notes, and an honest, hedged virality assessment.

${BRAND_BIBLE}

CRITICAL HONESTY RULE: You do not have live access to real analytics, retention data, or platform performance data unless
the user gives it to you. Every score, percentage, or prediction you produce (virality scores, retention curve, reach
estimates) is an informed creative judgment, not a measurement -- never present it as real data, never guarantee an
outcome, and say so if asked. A "72/100 hook score" means "an experienced creative director would rate this hook fairly
strong," not a fact about what will happen.

RULES:
1. Only ever recommend organic, platform-compliant, brand-safe content. Never suggest fake engagement, misleading claims,
   or manipulating a platform's algorithm through prohibited means.
2. Every idea leads with a wild hook, drops knowledge second, and ends curious -- per brand rules. Never end flat or
   corporate.
3. Any AI avatar, voice, or synthetic likeness referenced in filming instructions must be flagged as needing disclosure.
4. Keep the script and shot list realistic for a solo creator filming on a phone -- no Hollywood-scale asks unless the
   user specifically says they have a bigger production setup.
5. Respond with ONLY raw JSON, no markdown fences, no extra text, in exactly this shape:
{
  "title": "...",
  "hook": "...",
  "why_it_works": "one or two sentences on the psychological driver",
  "target_audience": "...",
  "primary_emotion": "...",
  "script": "full short script, ready to read on camera",
  "shot_list": [{"shot": "Shot 1", "type": "Medium Shot / Close-up / B-roll / Overhead / etc.", "notes": "what's happening", "duration": "e.g. 2.3 seconds"}],
  "filming_notes": "practical director-style notes: where to stand/look, pacing, energy, emphasis",
  "editing_notes": "jump cuts, captions, music timing, pacing notes",
  "thumbnail_concept": "...",
  "music_style": "...",
  "cta": "...",
  "alt_hooks": ["...", "..."],
  "alt_titles": ["...", "..."],
  "repurposing_plan": "how this becomes 2-3 other formats/platforms",
  "virality_scores": {
    "hook_score": {"score": 0, "confidence": "Low/Medium/High", "explanation": "..."},
    "retention_score": {"score": 0, "confidence": "Low/Medium/High", "explanation": "..."},
    "share_score": {"score": 0, "confidence": "Low/Medium/High", "explanation": "..."},
    "save_score": {"score": 0, "confidence": "Low/Medium/High", "explanation": "..."},
    "business_impact_score": {"score": 0, "confidence": "Low/Medium/High", "explanation": "..."}
  },
  "retention_prediction": [{"second": 0, "percent": 100}, {"second": 3, "percent": 0}, {"second": 10, "percent": 0}, {"second": 20, "percent": 0}, {"second": 40, "percent": 0}, {"second": 60, "percent": 0}]
}
`.trim();

const PHOTO_COACH_PROMPT = `
You are the MetaKittyz Media Coach -- you look at an actual photo the user just captured of themselves on their
own camera and give real, specific, actionable coaching to make it stronger personal-brand content.

${BRAND_BIBLE}

RULES:
1. You are looking at a REAL photo, not predicting a hypothetical -- describe what you actually observe (lighting
   direction and quality, framing/composition, background, visible expression and energy, color/wardrobe), don't
   hedge on what's visibly true in the image itself.
2. You cannot know things not visible in the frame (actual lighting equipment used, room dimensions, what happens a
   moment before/after) -- don't invent details you can't see.
3. Judge brand fit against the MetaKittyz visual identity above: true black or dark, high-contrast background reads
   better on-brand than a busy/pastel one; energetic, expressive, "loud" energy fits better than flat/neutral;
   never suggest the person needs to look "corporate" or "polished" in a sterile way.
4. Be warm and specific, never harsh -- like a supportive friend who happens to have a great eye, not a critic.
5. Always give ONE clear top-priority fix, not a wall of notes.
6. Respond with ONLY raw JSON, no markdown fences, no extra text, in exactly this shape:
{
  "lighting": {"score": 0, "notes": "what you actually see"},
  "framing": {"score": 0, "notes": "composition, headroom, angle"},
  "expression_energy": {"score": 0, "notes": "what the expression/energy reads as"},
  "brand_fit": {"score": 0, "notes": "how well it matches the MetaKittyz visual identity"},
  "top_fix": "the single most impactful change to make right now",
  "overall_verdict": "one warm, encouraging sentence summing it up"
}
`.trim();

const AVATAR_SHEET_PROMPT = `
You are the MetaKittyz Media Coach, producing an "Avatar Reference Sheet" from a set of real photos the user just
captured of themselves from different angles (front, 3/4 left, 3/4 right, profile, close-up, etc. -- whichever they
provided). This reference sheet is used to plan a real filmed video -- for ads, education, or general brand content.

${BRAND_BIBLE}

RULES:
1. You are looking at REAL photos -- describe what's actually visible in each labeled angle (lighting, framing,
   expression), don't invent details you can't see.
2. Your job is to turn these stills into a practical, filmable plan: which angles/shots work for which purpose,
   concrete camera directions, and a ready-to-use video prompt/brief someone could hand to a videographer (or use
   as a shot-planning reference themselves).
3. Judge brand fit against the MetaKittyz visual identity above -- true black/dark high-contrast backgrounds,
   energetic and expressive over flat/neutral, on-brand color accents where relevant.
4. Never guarantee ad performance or business outcomes from following this plan -- it's a production plan, not a
   performance guarantee.
5. Respond with ONLY raw JSON, no markdown fences, no extra text, in exactly this shape:
{
  "angle_notes": [{"angle": "Front", "notes": "what's usable about this angle, what to adjust"}],
  "shot_list": [{"shot": "Shot 1", "type": "e.g. Medium close-up, talking head", "use_case": "ads / education / social", "notes": "framing/energy direction"}],
  "video_prompt": "a complete, ready-to-use paragraph describing the video to film or generate -- setting, framing, energy, wardrobe/background cues, pacing -- written for either a videographer or an AI video tool",
  "recommended_use_cases": ["ads", "education", "social/organic"],
  "overall_recommendation": "one clear, encouraging next step"
}
`.trim();

const AGENTS = [
  {
    id: "nova",
    name: "NOVA",
    role: "AI Content Creator",
    tagline: "Writes everything in your brand voice",
    color: COLORS.pink,
    icon: Sparkles,
    producesContent: true,
    extraRules: `
YOUR JOB: Write all content in the MetaKittyz brand voice -- hooks, captions, ad scripts, video scripts, bios.
Reference the brand bible for tone. Every piece of content needs a wild hook first, knowledge second, and a curious close.
You do not adapt content for specific platforms (that's ARIA's job) and you do not judge compliance (that's GUARDIAN's job).`,
    quickActions: [
      { label: "Write IG hook", prompt: "Write me a scroll-stopping Instagram hook for my next AI Hack post." },
      { label: "3 content ideas", prompt: "Give me 3 content ideas for this week, one from a different pillar each." },
      { label: "Draft ad script", prompt: "Draft a 30-second ad script promoting my Live Build Series." },
    ],
  },
  {
    id: "aria",
    name: "ARIA",
    role: "Social Media Manager",
    tagline: "Adapts content per platform",
    color: COLORS.teal,
    icon: Share2,
    producesContent: true,
    extraRules: `
YOUR JOB: Take content NOVA (or the user) already wrote and adapt it per platform -- Instagram, TikTok, LinkedIn, and X.
Match each platform's format, pacing, and character limits (X: 280 chars, Threads: 500 chars). Keep the brand voice intact --
adapt the wrapper, not the personality. You do not originate brand-new ideas from scratch (that's NOVA's job) and you do not judge compliance (GUARDIAN's job).`,
    quickActions: [
      { label: "Adapt for TikTok", prompt: "Adapt this into a TikTok script with on-screen text beats: " },
      { label: "Adapt for LinkedIn", prompt: "Adapt this into a LinkedIn post, still on-brand but slightly more polished: " },
      { label: "Adapt for X", prompt: "Adapt this into an X post under 280 characters: " },
    ],
  },
  {
    id: "guardian",
    name: "GUARDIAN",
    role: "QA & Compliance Agent",
    tagline: "The final checkpoint before anything posts",
    color: COLORS.yellow,
    icon: ShieldCheck,
    producesContent: false,
    extraRules: `
YOUR JOB: Review content for FTC disclosure requirements (AI avatars/synthetic voice/paid partnerships must be disclosed),
brand voice consistency (does it match the MetaKittyz brand bible), and false or unverifiable claims (no guaranteed results,
income, or growth numbers). Flag anything that needs fixing, in plain, precise language -- not brand voice, precision matters more here.
You never soften a real issue to be agreeable. You are the last checkpoint. Nothing bypasses you.`,
    quickActions: [
      { label: "Run FTC check", prompt: "Run an FTC disclosure check on this content: " },
      { label: "Check brand voice", prompt: "Check this content against the MetaKittyz brand voice: " },
      { label: "Fact-check claims", prompt: "Fact-check this content for false or unverifiable claims: " },
    ],
  },
  {
    id: "pulse",
    name: "PULSE",
    role: "Visual Systems Agent",
    tagline: "Keeps every graphic on-brand",
    color: COLORS.purple,
    icon: ImageIcon,
    producesContent: true,
    extraRules: `
YOUR JOB: Propose visual direction -- graphic concepts, overlay text, color pairings, thumbnail ideas -- that match the
MetaKittyz palette and neon/tropical/matrix aesthetic. You describe visual concepts in words; you do not generate final
brand copy (NOVA's job) or judge compliance (GUARDIAN's job).`,
    quickActions: [
      { label: "Visual concept", prompt: "Suggest a visual concept for my next AI Hack post thumbnail." },
      { label: "Palette check", prompt: "Check if this idea fits the MetaKittyz color palette and suggest fixes: " },
      { label: "Overlay text ideas", prompt: "Give me 3 short overlay text options for a stream clip about quantum computing." },
    ],
  },
  {
    id: "reach",
    name: "REACH",
    role: "Growth, Scheduling & Trend Forecasting",
    tagline: "Plans when and how you post, and reads where attention is heading next",
    color: COLORS.coral,
    icon: Rocket,
    producesContent: false,
    extraRules: `
YOUR JOB: Recommend posting cadence, timing, and growth tactics (trend-jacking, cross-posting strategy, series structure),
AND assess the trajectory of trends/ideas brought to you -- stage, audience psychology, and repurposing potential.

TREND FORECASTING FRAMEWORK (use this whenever asked to evaluate a trend, niche, or content idea):
1. What's actually happening -- describe the trend/idea plainly.
2. Why it's happening -- the psychological or cultural driver (curiosity, belonging, status, humor, novelty, etc.).
3. Stage call: Emerging / Rising / Exploding / Peak / Saturated / Declining.
4. Estimated virality potential, estimated revenue potential, and competition level -- each as Low / Medium / High, with a
   one-line reason. These are informed estimates, never guarantees.
5. Shelf life: short (hours-days) / medium (weeks-months) / long (evergreen).
6. Repurposing angle: how one idea could reasonably extend across formats, if it fits.

CRITICAL HONESTY RULE: You do not have live access to real-time platform analytics or scraped trend data unless the user
pastes it to you. Every stage/score you give is an informed estimate based on patterns and reasoning, not a measurement --
say so plainly if asked, and never invent a statistic to sound more data-backed than you are.

You give strategic, scheduling, and trend-trajectory advice -- not final copy (NOVA/ARIA's job) and not analysis of past
performance data the user already has (SPARK's job). Never promise specific growth numbers or guaranteed outcomes -- frame
everything as strategy and estimate, not guarantees.`,
    quickActions: [
      { label: "Posting schedule", prompt: "Suggest a posting schedule for this week across Instagram, TikTok, and X." },
      { label: "Score this trend", prompt: "Analyze this trend/idea using the trend forecasting framework -- stage, psychology, virality/revenue/competition estimate, shelf life: " },
      { label: "What's next", prompt: "Based on general patterns, what should I watch for in my niche over the next 30-90 days?" },
    ],
  },
  {
    id: "spark",
    name: "SPARK",
    role: "Analytics Agent",
    tagline: "Reads the numbers so you don't have to",
    color: COLORS.green,
    icon: BarChart3,
    producesContent: false,
    extraRules: `
YOUR JOB: Interpret whatever metrics or numbers the user gives you (followers, engagement rate, watch time, top posts) and
summarize what they mean in plain language, with one clear recommendation. You do not set future strategy (REACH's job) or
write copy (NOVA/ARIA's job). Never fabricate numbers -- only reason about numbers the user actually provides.`,
    quickActions: [
      { label: "Weekly summary", prompt: "Summarize what my current metrics on the dashboard suggest about this week." },
      { label: "Top performer", prompt: "Based on what I tell you, help me identify what type of content is performing best." },
      { label: "Growth recommendation", prompt: "Give me one data-backed recommendation based on my current numbers." },
    ],
  },
];

const STATUS_LABELS = {
  idle: "Idle",
  thinking: "Thinking",
  drafting: "Drafting",
  guardian_review: "Awaiting Guardian",
  approved: "Approved",
  needs_revision: "Needs revision",
};

const STATUS_COLORS = {
  idle: "#A7A1B8",
  thinking: COLORS.teal,
  drafting: COLORS.purple,
  guardian_review: COLORS.yellow,
  approved: COLORS.green,
  needs_revision: COLORS.coral,
};

const PIPELINE_STEPS = ["idle", "thinking", "drafting", "guardian_review", "approved"];

/* ---------------------------------------------------------------
   HELPERS
--------------------------------------------------------------- */

function buildSystemPrompt(agent, jsonReviewMode) {
  let prompt = `You are ${agent.name}, the ${agent.role} on the MetaKittyz AI orchestration team.\n${agent.tagline}.\n\n${BRAND_BIBLE}\n\n${COMMON_GUARDRAILS}\n\n${agent.extraRules}`;
  if (agent.id === "guardian" && jsonReviewMode) {
    prompt += `\n\nFORMAL REVIEW MODE: You are running a formal compliance review on a piece of content.
Respond with ONLY raw JSON, no markdown fences, no extra text, in exactly this shape:
{"verdict":"approved" or "flagged","brand_voice_ok":true or false,"ftc_disclosure_ok":true or false,"no_false_claims_ok":true or false,"issues":["short issue strings, empty array if none"],"notes":"one or two plain-language sentences"}`;
  }
  return prompt;
}

function parseAgentReply(raw) {
  const thinkMatch = raw.match(/\[THINKING\]([\s\S]*?)\[\/THINKING\]/i);
  const respMatch = raw.match(/\[RESPONSE\]([\s\S]*?)\[\/RESPONSE\]/i);
  if (respMatch) {
    return {
      thinking: thinkMatch ? thinkMatch[1].trim() : "",
      response: respMatch[1].trim(),
    };
  }
  return { thinking: "", response: raw.trim() };
}

async function callClaude(systemPrompt, history) {
  const response = await fetch("/api/claude", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      system: systemPrompt,
      messages: history,
    }),
  });
  const data = await response.json();
  const text = (data.content || [])
    .map((b) => (b.type === "text" ? b.text : ""))
    .filter(Boolean)
    .join("\n");
  return text;
}

async function callClaudeVision(systemPrompt, base64Image, mediaType, userText) {
  const response = await fetch("/api/claude", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      system: systemPrompt,
      messages: [
        {
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: mediaType, data: base64Image } },
            { type: "text", text: userText },
          ],
        },
      ],
    }),
  });
  const data = await response.json();
  const text = (data.content || [])
    .map((b) => (b.type === "text" ? b.text : ""))
    .filter(Boolean)
    .join("\n");
  return text;
}

async function callClaudeVisionMulti(systemPrompt, images, userText) {
  // images: array of { base64, mediaType, label }
  const content = [];
  images.forEach((img) => {
    if (img.label) content.push({ type: "text", text: `Angle: ${img.label}` });
    content.push({ type: "image", source: { type: "base64", media_type: img.mediaType, data: img.base64 } });
  });
  content.push({ type: "text", text: userText });

  const response = await fetch("/api/claude", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1500,
      system: systemPrompt,
      messages: [{ role: "user", content }],
    }),
  });
  const data = await response.json();
  const text = (data.content || [])
    .map((b) => (b.type === "text" ? b.text : ""))
    .filter(Boolean)
    .join("\n");
  return text;
}


  "to someone she likes, not a polished announcer or a corporate narrator. Relaxed pacing, genuine warmth, easy to listen to.";

function speakBrowser(text) {
  try {
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    const voices = window.speechSynthesis.getVoices();
    const femaleVoice = voices.find((v) => /female|samantha|victoria|karen|zira|susan|jenny|aria/i.test(v.name));
    if (femaleVoice) utter.voice = femaleVoice;
    utter.rate = 0.98;
    utter.pitch = 1.02;
    window.speechSynthesis.speak(utter);
  } catch (e) {
    console.error("Browser TTS error", e);
  }
}

async function speakOpenAI(text, apiKey, voice) {
  const response = await fetch("/api/openai-tts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      apiKey,
      voice: voice || "shimmer",
      input: text,
      instructions: OPENAI_VOICE_INSTRUCTIONS,
    }),
  });
  if (!response.ok) throw new Error(`OpenAI TTS failed: ${response.status}`);
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const audio = new Audio(url);
  audio.play();
}

async function speak(text, ttsSettings) {
  if (ttsSettings && ttsSettings.apiKey) {
    try {
      await speakOpenAI(text, ttsSettings.apiKey, ttsSettings.voice);
      return;
    } catch (e) {
      console.error("OpenAI TTS failed, falling back to browser voice", e);
    }
  }
  speakBrowser(text);
}

async function storageGet(key, fallback) {
  try {
    const res = await window.storage.get(key, false);
    return res ? JSON.parse(res.value) : fallback;
  } catch (e) {
    return fallback;
  }
}
async function storageSet(key, value) {
  try {
    await window.storage.set(key, JSON.stringify(value), false);
  } catch (e) {
    console.error("storage set failed", key, e);
  }
}

const uid = () => Math.random().toString(36).slice(2, 10);

/* ---------------------------------------------------------------
   SMALL UI PIECES
--------------------------------------------------------------- */

function AgentRing({ agent, size = 44 }) {
  const Icon = agent.icon;
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        padding: 3,
        background: `conic-gradient(from 180deg, ${agent.color}, #FFD23C, #4BE8FF, #B06BFF, ${agent.color})`,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
      }}
    >
      <div
        style={{
          width: "100%",
          height: "100%",
          borderRadius: "50%",
          background: "#000000",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Icon size={size * 0.42} color={agent.color} strokeWidth={2} />
      </div>
    </div>
  );
}

function StatusBadge({ status }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 5,
        fontSize: 11,
        fontFamily: "'Outfit', sans-serif",
        letterSpacing: 0.5,
        textTransform: "uppercase",
        color: STATUS_COLORS[status] || "#A7A1B8",
        border: `1px solid ${STATUS_COLORS[status] || "#A7A1B8"}55`,
        background: `${STATUS_COLORS[status] || "#A7A1B8"}14`,
        borderRadius: 20,
        padding: "3px 10px",
      }}
    >
      <span style={{ width: 6, height: 6, borderRadius: "50%", background: STATUS_COLORS[status] || "#A7A1B8" }} />
      {STATUS_LABELS[status] || status}
    </span>
  );
}

function PipelineStepper({ status }) {
  const activeIdx = status === "needs_revision" ? 3 : PIPELINE_STEPS.indexOf(status);
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 4, marginTop: 8 }}>
      {PIPELINE_STEPS.map((step, i) => (
        <React.Fragment key={step}>
          <div
            title={STATUS_LABELS[step]}
            style={{
              width: 8,
              height: 8,
              borderRadius: "50%",
              background: i <= activeIdx ? STATUS_COLORS[status] || COLORS.teal : "#A7A1B833",
              transition: "background 0.3s",
            }}
          />
          {i < PIPELINE_STEPS.length - 1 && (
            <div style={{ flex: 1, height: 2, background: i < activeIdx ? (STATUS_COLORS[status] || COLORS.teal) : "#A7A1B833" }} />
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

function MetricCard({ label, value, accent }) {
  return (
    <div
      style={{
        background: "#141414",
        border: `1px solid ${accent}33`,
        borderRadius: 14,
        padding: "16px 18px",
        flex: 1,
        minWidth: 130,
      }}
    >
      <p style={{ margin: 0, fontSize: 11, letterSpacing: 1, textTransform: "uppercase", color: "#A7A1B8", fontFamily: "'Outfit', sans-serif" }}>{label}</p>
      <p style={{ margin: "6px 0 0", fontSize: 26, fontWeight: 700, color: accent, fontFamily: "'Tektur', sans-serif" }}>{value}</p>
    </div>
  );
}

/* ---------------------------------------------------------------
   MAIN APP
--------------------------------------------------------------- */

export default function MetaKittyzPortal() {
  const [view, setView] = useState("dashboard"); // dashboard | agent:<id> | queue
  const [loaded, setLoaded] = useState(false);

  const [chats, setChats] = useState({}); // agentId -> [{id, role, content, thinking}]
  const [statuses, setStatuses] = useState({}); // agentId -> status
  const [queue, setQueue] = useState([]); // content queue items
  const METRICS_VERSION = 2; // bump this whenever the hardcoded seed data changes, so stale storage gets replaced
  const [metrics, setMetrics] = useState({
    dataVersion: METRICS_VERSION,
    handle: "@metakittyz",
    bio: "Talk nerdy to me\u{1F9E0}\u{1F308} Building AI teams live so mine works while I sleep. Teaching you to build yours! No code, just vibes. Watch me build",
    lastSynced: "Jul 17, 2026 (via Zapier)",
    followers: { instagram: 499, tiktok: 0, youtube: 0, x: 0 },
    following: 372,
    postCount: 27,
    engagementRate: 5.4,
    growthHistory: [
      { date: "Jul 17", followers: 499 },
    ],
    recentPosts: [
      { date: "Jul 17", likes: 4, comments: 0 },
      { date: "Jul 2", likes: 11, comments: 2 },
      { date: "Jun 27", likes: 12, comments: 5 },
      { date: "Jun 25", likes: 11, comments: 0 },
      { date: "Jun 24", likes: 13, comments: 2 },
    ],
  });
  const [pending, setPending] = useState({}); // agentId -> bool loading
  const [autoSpeak, setAutoSpeak] = useState({});
  const [input, setInput] = useState("");
  const [newPoint, setNewPoint] = useState({ date: "", followers: "" });
  const chatEndRef = useRef(null);

  const [execBrief, setExecBrief] = useState({
    priorities: ["Post 1x/day across IG + TikTok", "Finish onboarding flow for prompt packs", "Prep partner meeting materials"],
    risks: "Single-platform follower base (Instagram only) -- no redundancy if reach drops on one app.",
    opportunities: "Prompt pack catalog can expand into a paid tier; live-build format is differentiated vs polished competitor content.",
  });
  const [revenue, setRevenue] = useState({ entries: [] }); // {id, product, amount, date}
  const [calendar, setCalendar] = useState({ entries: [] }); // {id, date, platform, title, status}
  const [reportCopied, setReportCopied] = useState(false);
  const [ttsSettings, setTtsSettings] = useState({ apiKey: "", voice: "shimmer" });
  const [showVoiceSettings, setShowVoiceSettings] = useState(false);

  useEffect(() => {
    (async () => {
      const c = await storageGet("mkz:chats", {});
      const s = await storageGet("mkz:statuses", {});
      const q = await storageGet("mkz:queue", []);
      const m = await storageGet("mkz:metrics", null);
      const eb = await storageGet("mkz:execBrief", null);
      const rv = await storageGet("mkz:revenue", null);
      const cal = await storageGet("mkz:calendar", null);
      const tts = await storageGet("mkz:ttsSettings", null);
      setChats(c);
      setStatuses(s);
      setQueue(q);
      if (eb) setExecBrief(eb);
      if (rv) setRevenue(rv);
      if (cal) setCalendar(cal);
      if (tts) setTtsSettings(tts);
      if (m && m.dataVersion === METRICS_VERSION) {
        // stored data matches the current real-data seed -- safe to trust (e.g. user added growth points)
        setMetrics(m);
      } else if (m) {
        // stored data is a stale snapshot from before the last real sync -- keep the fresh real seed and overwrite storage with it
        storageSet("mkz:metrics", metrics);
      }
      setLoaded(true);
    })();
  }, []);

  useEffect(() => { if (loaded) storageSet("mkz:execBrief", execBrief); }, [execBrief, loaded]);
  useEffect(() => { if (loaded) storageSet("mkz:revenue", revenue); }, [revenue, loaded]);
  useEffect(() => { if (loaded) storageSet("mkz:calendar", calendar); }, [calendar, loaded]);
  useEffect(() => { if (loaded) storageSet("mkz:ttsSettings", ttsSettings); }, [ttsSettings, loaded]);


  useEffect(() => { if (loaded) storageSet("mkz:chats", chats); }, [chats, loaded]);
  useEffect(() => { if (loaded) storageSet("mkz:statuses", statuses); }, [statuses, loaded]);
  useEffect(() => { if (loaded) storageSet("mkz:queue", queue); }, [queue, loaded]);
  useEffect(() => { if (loaded) storageSet("mkz:metrics", metrics); }, [metrics, loaded]);

  useEffect(() => {
    if (chatEndRef.current) chatEndRef.current.scrollIntoView({ behavior: "smooth" });
  }, [view, chats]);

  const setStatus = (agentId, status) => setStatuses((p) => ({ ...p, [agentId]: status }));

  const sendToAgent = useCallback(async (agentId, text) => {
    if (!text.trim()) return;
    const agent = AGENTS.find((a) => a.id === agentId);
    const userMsg = { id: uid(), role: "user", content: text };
    setChats((prev) => ({ ...prev, [agentId]: [...(prev[agentId] || []), userMsg] }));
    setPending((p) => ({ ...p, [agentId]: true }));
    setStatus(agentId, "thinking");
    try {
      const history = [...(chats[agentId] || []), userMsg].map((m) => ({
        role: m.role,
        content: m.content,
      }));
      const raw = await callClaude(buildSystemPrompt(agent, false), history);
      const { thinking, response } = parseAgentReply(raw);
      const botMsg = { id: uid(), role: "assistant", content: response, thinking };
      setChats((prev) => ({ ...prev, [agentId]: [...(prev[agentId] || []), userMsg, botMsg] }));
      setStatus(agentId, agent.producesContent ? "drafting" : "idle");
      if (autoSpeak[agentId]) speak(response, ttsSettings);
    } catch (e) {
      const errMsg = { id: uid(), role: "assistant", content: "Connection hiccup -- try that again in a second.", thinking: "" };
      setChats((prev) => ({ ...prev, [agentId]: [...(prev[agentId] || []), userMsg, errMsg] }));
      setStatus(agentId, "idle");
    } finally {
      setPending((p) => ({ ...p, [agentId]: false }));
    }
  }, [chats, autoSpeak, ttsSettings]);

  const sendToGuardianQueue = (agentId, content, sourceLabel) => {
    const item = {
      id: uid(),
      agentId,
      sourceLabel: sourceLabel || null,
      content,
      status: "guardian_review",
      issues: [],
      notes: "",
      createdAt: new Date().toLocaleString(),
    };
    setQueue((prev) => [item, ...prev]);
    if (AGENTS.find((a) => a.id === agentId)) setStatus(agentId, "guardian_review");
  };

  const [growthTopic, setGrowthTopic] = useState("");
  const [growthPillar, setGrowthPillar] = useState("Tech-Sexy-Nerd");
  const [growthBatch, setGrowthBatch] = useState([]);
  const [growthLoading, setGrowthLoading] = useState(false);
  const [growthError, setGrowthError] = useState("");

  const generateContentBatch = async () => {
    if (!growthTopic.trim()) return;
    setGrowthLoading(true);
    setGrowthError("");
    try {
      const raw = await callClaude(GROWTH_ENGINE_PROMPT, [
        { role: "user", content: `Topic: ${growthTopic}\nPillar: ${growthPillar}\nGenerate a full content batch atomized across formats.` },
      ]);
      const cleaned = raw.replace(/```json|```/g, "").trim();
      let parsed;
      try {
        parsed = JSON.parse(cleaned);
      } catch (e) {
        parsed = [{ format: "raw", platform: "-", content: cleaned }];
      }
      setGrowthBatch(Array.isArray(parsed) ? parsed : [parsed]);
    } catch (e) {
      setGrowthError("Batch generation failed -- try again.");
    } finally {
      setGrowthLoading(false);
    }
  };

  const [studioTopic, setStudioTopic] = useState("");
  const [studioBrief, setStudioBrief] = useState(null);
  const [studioLoading, setStudioLoading] = useState(false);
  const [studioError, setStudioError] = useState("");

  const generateContentBrief = async () => {
    if (!studioTopic.trim()) return;
    setStudioLoading(true);
    setStudioError("");
    try {
      const raw = await callClaude(CONTENT_STUDIO_PROMPT, [
        { role: "user", content: `Topic: ${studioTopic}\nGenerate a complete content brief.` },
      ]);
      const cleaned = raw.replace(/```json|```/g, "").trim();
      let parsed;
      try {
        parsed = JSON.parse(cleaned);
      } catch (e) {
        parsed = { title: studioTopic, script: cleaned };
      }
      setStudioBrief(parsed);
    } catch (e) {
      setStudioError("Brief generation failed -- try again.");
    } finally {
      setStudioLoading(false);
    }
  };

  // Media Coach -- photos live only in memory for this session, never persisted to storage
  const [capturedPhoto, setCapturedPhoto] = useState(null); // dataURL
  const [photoAnalysis, setPhotoAnalysis] = useState(null);
  const [photoLoading, setPhotoLoading] = useState(false);
  const [photoError, setPhotoError] = useState("");
  const [coachStep, setCoachStep] = useState(1);

  const analyzeCapturedPhoto = async (dataUrl) => {
    setPhotoLoading(true);
    setPhotoError("");
    setPhotoAnalysis(null);
    try {
      const [header, base64Data] = dataUrl.split(",");
      const mediaType = header.match(/data:(.*);base64/)[1];
      const raw = await callClaudeVision(
        PHOTO_COACH_PROMPT,
        base64Data,
        mediaType,
        "Analyze this photo for MetaKittyz personal brand content and coach me on it."
      );
      const cleaned = raw.replace(/```json|```/g, "").trim();
      let parsed;
      try {
        parsed = JSON.parse(cleaned);
      } catch (e) {
        parsed = { overall_verdict: cleaned };
      }
      setPhotoAnalysis(parsed);
      setCoachStep(4);
    } catch (e) {
      setPhotoError("Analysis failed -- check your connection and try again.");
    } finally {
      setPhotoLoading(false);
    }
  };

  const [coachMode, setCoachMode] = useState("quick"); // "quick" | "avatar"
  const ANGLE_LABELS = ["Front - neutral", "3/4 Left", "3/4 Right", "Profile", "Close-up - expressive"];
  const [avatarShots, setAvatarShots] = useState({}); // { angleLabel: dataUrl }
  const [avatarAngleIndex, setAvatarAngleIndex] = useState(0);
  const [avatarSheet, setAvatarSheet] = useState(null);
  const [avatarLoading, setAvatarLoading] = useState(false);
  const [avatarError, setAvatarError] = useState("");
  const [avatarUseCase, setAvatarUseCase] = useState("ads");

  const captureAvatarShot = (dataUrl, angleLabel) => {
    setAvatarShots((prev) => ({ ...prev, [angleLabel]: dataUrl }));
    if (avatarAngleIndex < ANGLE_LABELS.length - 1) {
      setAvatarAngleIndex((i) => i + 1);
    }
  };

  const retakeAvatarShot = (angleLabel) => {
    setAvatarShots((prev) => {
      const next = { ...prev };
      delete next[angleLabel];
      return next;
    });
    setAvatarAngleIndex(ANGLE_LABELS.indexOf(angleLabel));
  };

  const generateAvatarSheet = async () => {
    const shotEntries = Object.entries(avatarShots);
    if (shotEntries.length === 0) return;
    setAvatarLoading(true);
    setAvatarError("");
    setAvatarSheet(null);
    try {
      const images = shotEntries.map(([label, dataUrl]) => {
        const [header, base64Data] = dataUrl.split(",");
        const mediaType = header.match(/data:(.*);base64/)[1];
        return { base64: base64Data, mediaType, label };
      });
      const raw = await callClaudeVisionMulti(
        AVATAR_SHEET_PROMPT,
        images,
        `Build a complete Avatar Reference Sheet from these ${images.length} angle(s). Primary intended use case: ${avatarUseCase}.`
      );
      const cleaned = raw.replace(/```json|```/g, "").trim();
      let parsed;
      try {
        parsed = JSON.parse(cleaned);
      } catch (e) {
        parsed = { overall_recommendation: cleaned };
      }
      setAvatarSheet(parsed);
    } catch (e) {
      setAvatarError("Reference sheet generation failed -- try again.");
    } finally {
      setAvatarLoading(false);
    }
  };

  const resetAvatarSheet = () => {
    setAvatarShots({});
    setAvatarAngleIndex(0);
    setAvatarSheet(null);
    setAvatarError("");
  };

  const runGuardianReview = async (itemId) => {
    const item = queue.find((q) => q.id === itemId);
    if (!item) return;
    setQueue((prev) => prev.map((q) => (q.id === itemId ? { ...q, reviewing: true } : q)));
    try {
      const guardian = AGENTS.find((a) => a.id === "guardian");
      const raw = await callClaude(
        buildSystemPrompt(guardian, true),
        [{ role: "user", content: `Review this content:\n\n${item.content}` }]
      );
      const cleaned = raw.replace(/```json|```/g, "").trim();
      let parsed;
      try {
        parsed = JSON.parse(cleaned);
      } catch (e) {
        parsed = { verdict: "flagged", issues: ["Could not auto-parse review output."], notes: cleaned.slice(0, 300) };
      }
      setQueue((prev) =>
        prev.map((q) =>
          q.id === itemId
            ? { ...q, status: parsed.verdict === "approved" ? "approved" : "flagged", issues: parsed.issues || [], notes: parsed.notes || "", reviewing: false }
            : q
        )
      );
      setStatus(item.agentId, parsed.verdict === "approved" ? "approved" : "needs_revision");
    } catch (e) {
      setQueue((prev) => prev.map((q) => (q.id === itemId ? { ...q, reviewing: false, notes: "Review failed -- try again." } : q)));
    }
  };

  const manualSetQueueStatus = (itemId, status) => {
    const item = queue.find((q) => q.id === itemId);
    setQueue((prev) => prev.map((q) => (q.id === itemId ? { ...q, status } : q)));
    if (item) setStatus(item.agentId, status === "approved" ? "approved" : status === "flagged" ? "needs_revision" : status);
  };

  const totalFollowers = Object.values(metrics.followers).reduce((a, b) => a + Number(b || 0), 0);
  const pendingCount = queue.filter((q) => q.status === "guardian_review").length;
  const totalRevenue = revenue.entries.reduce((a, e) => a + Number(e.amount || 0), 0);
  const upcomingCalendar = [...calendar.entries].sort((a, b) => (a.date > b.date ? 1 : -1));
  const postedThisWeek = calendar.entries.filter((e) => e.status === "posted").length;

  const addRevenueEntry = (entry) => setRevenue((r) => ({ entries: [{ id: uid(), ...entry }, ...r.entries] }));
  const deleteRevenueEntry = (id) => setRevenue((r) => ({ entries: r.entries.filter((e) => e.id !== id) }));
  const addCalendarEntry = (entry) => setCalendar((c) => ({ entries: [{ id: uid(), status: "planned", ...entry }, ...c.entries] }));
  const updateCalendarEntry = (id, patch) => setCalendar((c) => ({ entries: c.entries.map((e) => (e.id === id ? { ...e, ...patch } : e)) }));
  const deleteCalendarEntry = (id) => setCalendar((c) => ({ entries: c.entries.filter((e) => e.id !== id) }));

  const buildWeeklyReport = () => {
    const lines = [
      `${metrics.handle.replace("@", "").toUpperCase()} -- WEEKLY BUSINESS REPORT`,
      new Date().toLocaleDateString(),
      "",
      "PRIORITIES",
      ...execBrief.priorities.filter(Boolean).map((p, i) => `${i + 1}. ${p}`),
      "",
      "KEY METRICS",
      `Followers (Instagram): ${metrics.followers.instagram.toLocaleString()}`,
      `Engagement rate: ${metrics.engagementRate}%`,
      `Revenue tracked: $${totalRevenue.toLocaleString()}`,
      `Posts marked live this period: ${postedThisWeek}`,
      "",
      "RISKS",
      execBrief.risks || "None logged.",
      "",
      "OPPORTUNITIES",
      execBrief.opportunities || "None logged.",
      "",
      "UPCOMING CONTENT",
      ...(upcomingCalendar.length
        ? upcomingCalendar.slice(0, 8).map((e) => `${e.date} -- ${e.platform} -- ${e.title} [${e.status}]`)
        : ["Nothing scheduled yet."]),
    ];
    return lines.join("\n");
  };

  const copyWeeklyReport = async () => {
    try {
      await navigator.clipboard.writeText(buildWeeklyReport());
      setReportCopied(true);
      setTimeout(() => setReportCopied(false), 2000);
    } catch (e) {
      console.error("copy failed", e);
    }
  };

  const addGrowthPoint = () => {
    if (!newPoint.date || !newPoint.followers) return;
    setMetrics((m) => ({
      ...m,
      growthHistory: [...m.growthHistory, { date: newPoint.date, followers: Number(newPoint.followers) }],
    }));
    setNewPoint({ date: "", followers: "" });
  };

  const resetDemoData = async () => {
    setChats({});
    setStatuses({});
    setQueue([]);
    await storageSet("mkz:chats", {});
    await storageSet("mkz:statuses", {});
    await storageSet("mkz:queue", []);
  };

  /* ---------- shared page shell ---------- */

  const pageStyle = {
    background: COLORS.bg,
    minHeight: 600,
    color: "#F5F2FA",
    fontFamily: "'Outfit', 'Segoe UI', sans-serif",
    padding: "22px 22px 32px",
    borderRadius: 16,
  };

  const NavButton = ({ id, label, icon: Icon, badge }) => (
    <button
      onClick={() => setView(id)}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 6,
        background: view === id ? "#A7A1B822" : "transparent",
        border: `1px solid ${view === id ? COLORS.teal : "#A7A1B833"}`,
        color: view === id ? COLORS.teal : "#A7A1B8",
        borderRadius: 10,
        padding: "7px 12px",
        fontSize: 12,
        fontFamily: "'Outfit', sans-serif",
        cursor: "pointer",
        position: "relative",
      }}
    >
      <Icon size={14} /> {label}
      {badge > 0 && (
        <span style={{ background: COLORS.pink, color: "#F5F2FA", borderRadius: 20, fontSize: 10, padding: "1px 6px", marginLeft: 2 }}>{badge}</span>
      )}
    </button>
  );

  return (
    <div style={pageStyle}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Tektur:wght@700;900&family=Outfit:wght@400;500;700&family=Smooch+Sans:wght@400;600&display=swap');
        * { box-sizing: border-box; }
        ::placeholder { color: #A7A1B8; }
        button { font-family: inherit; }
        input, textarea { font-family: inherit; background:#141414; border:1px solid #A7A1B833; color:#F5F2FA; border-radius:8px; padding:8px 10px; }
        input:focus, textarea:focus { outline: 1px solid ${COLORS.teal}; }
        .mkz-scroll::-webkit-scrollbar { width: 6px; }
        .mkz-scroll::-webkit-scrollbar-thumb { background: #A7A1B844; borderRadius: 10px; }
      `}</style>

      {/* HEADER */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12, marginBottom: 18 }}>
        <div>
          <h1 style={{ margin: 0, fontFamily: "'Tektur', sans-serif", fontSize: 26, fontWeight: 900 }}>
            <span style={{ color: "#F5F2FA" }}>META</span>
            <span style={{ color: COLORS.pink }}>KITTYZ</span>
          </h1>
          <p style={{ margin: "2px 0 0", fontSize: 11, letterSpacing: 2, color: COLORS.cyan, textTransform: "uppercase" }}>AI orchestration portal</p>
          <p style={{ margin: "2px 0 0", fontSize: 13, color: COLORS.pink, fontFamily: "'Smooch Sans', sans-serif", fontWeight: 600 }}>Matrix Meets Paradise.</p>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <NavButton id="dashboard" label="Studio" icon={Home} />
          <NavButton id="overview" label="Business overview" icon={BarChart3} />
          <NavButton id="growth" label="Growth engine" icon={TrendingUp} />
          <NavButton id="studio" label="Content studio" icon={Film} />
          <NavButton id="camera" label="Media Coach" icon={Camera} />
          <NavButton id="queue" label="Guardian queue" icon={ShieldCheck} badge={pendingCount} />
          <button onClick={() => setShowVoiceSettings((s) => !s)} title="Voice settings" style={{ display: "flex", alignItems: "center", gap: 6, background: showVoiceSettings ? "#A7A1B822" : "transparent", border: `1px solid ${showVoiceSettings ? COLORS.teal : "#A7A1B833"}`, color: showVoiceSettings ? COLORS.teal : "#A7A1B8", borderRadius: 10, padding: "7px 12px", fontSize: 12, cursor: "pointer" }}>
            <Volume2 size={13} /> Voice
          </button>
          <button onClick={resetDemoData} title="Reset all demo data" style={{ display: "flex", alignItems: "center", gap: 6, background: "transparent", border: "1px solid #A7A1B833", color: "#A7A1B8", borderRadius: 10, padding: "7px 12px", fontSize: 12, cursor: "pointer" }}>
            <RefreshCw size={13} /> Reset
          </button>
        </div>
      </div>

      {showVoiceSettings && (
        <div style={{ background: "#141414", border: `1px solid ${COLORS.teal}44`, borderRadius: 14, padding: 16, marginBottom: 18 }}>
          <p style={{ margin: "0 0 4px", fontSize: 12, letterSpacing: 1, textTransform: "uppercase", color: "#A7A1B8" }}>Voice settings -- OpenAI TTS</p>
          <p style={{ margin: "0 0 10px", fontSize: 11.5, color: "#A7A1B8", maxWidth: 560 }}>
            Add your own OpenAI API key to use a warmer, more natural voice for agent replies instead of the browser's
            built-in voice. <b style={{ color: COLORS.coral }}>Security note:</b> this key is stored in this browser's
            local artifact storage and sent directly from your browser to OpenAI -- don't paste a key here on a shared
            or public computer, and avoid it if you're screen-sharing with dev tools open. Leave it blank to keep using
            the free browser voice.
          </p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
            <input
              type="password"
              placeholder="sk-..."
              value={ttsSettings.apiKey}
              onChange={(e) => setTtsSettings((t) => ({ ...t, apiKey: e.target.value }))}
              style={{ flex: 1, minWidth: 220 }}
            />
            <select
              value={ttsSettings.voice}
              onChange={(e) => setTtsSettings((t) => ({ ...t, voice: e.target.value }))}
              style={{ background: "#000000", border: "1px solid #A7A1B833", color: "#F5F2FA", borderRadius: 8, padding: "8px 10px" }}
            >
              {["shimmer", "nova", "alloy", "echo", "fable", "onyx"].map((v) => <option key={v} value={v}>{v}</option>)}
            </select>
            <button
              onClick={() => speak("Hey, this is your MetaKittyz voice, checking in.", ttsSettings)}
              style={{ display: "flex", alignItems: "center", gap: 5, background: "transparent", border: `1px solid ${COLORS.teal}`, color: COLORS.teal, borderRadius: 8, padding: "7px 12px", fontSize: 12, cursor: "pointer" }}
            >
              <Volume2 size={13} /> Test voice
            </button>
          </div>
          <p style={{ margin: "8px 0 0", fontSize: 10.5, color: "#A7A1B8" }}>
            Default voice is "shimmer" with style instructions steering it toward warm, down-to-earth, and natural --
            switch the dropdown and hit "Test voice" to compare.
          </p>
        </div>
      )}

      {view === "dashboard" && (
        <Dashboard
          metrics={metrics}
          setMetrics={setMetrics}
          totalFollowers={totalFollowers}
          newPoint={newPoint}
          setNewPoint={setNewPoint}
          addGrowthPoint={addGrowthPoint}
          statuses={statuses}
          queue={queue}
          pendingCount={pendingCount}
          setView={setView}
          onQuick={(agentId, prompt) => { setView(`agent:${agentId}`); setTimeout(() => sendToAgent(agentId, prompt), 50); }}
          execBrief={execBrief}
          totalRevenue={totalRevenue}
          upcomingCalendar={upcomingCalendar}
          copyWeeklyReport={copyWeeklyReport}
          reportCopied={reportCopied}
          growthTopic={growthTopic}
          setGrowthTopic={setGrowthTopic}
          growthPillar={growthPillar}
          setGrowthPillar={setGrowthPillar}
          growthLoading={growthLoading}
          onGenerateGrowth={generateContentBatch}
        />
      )}

      {view === "overview" && (
        <BusinessOverview
          metrics={metrics}
          totalFollowers={totalFollowers}
          execBrief={execBrief}
          setExecBrief={setExecBrief}
          revenue={revenue}
          totalRevenue={totalRevenue}
          addRevenueEntry={addRevenueEntry}
          deleteRevenueEntry={deleteRevenueEntry}
          calendar={upcomingCalendar}
          addCalendarEntry={addCalendarEntry}
          updateCalendarEntry={updateCalendarEntry}
          deleteCalendarEntry={deleteCalendarEntry}
          copyWeeklyReport={copyWeeklyReport}
          reportCopied={reportCopied}
        />
      )}

      {view === "growth" && (
        <GrowthEngine
          topic={growthTopic}
          setTopic={setGrowthTopic}
          pillar={growthPillar}
          setPillar={setGrowthPillar}
          batch={growthBatch}
          loading={growthLoading}
          error={growthError}
          onGenerate={generateContentBatch}
          onSendToGuardian={(content) => sendToGuardianQueue("growth-engine", content, "Growth Engine")}
        />
      )}

      {view === "studio" && (
        <ContentStudio
          topic={studioTopic}
          setTopic={setStudioTopic}
          brief={studioBrief}
          loading={studioLoading}
          error={studioError}
          onGenerate={generateContentBrief}
          onSendToGuardian={(content) => sendToGuardianQueue("content-studio", content, "Content Studio")}
        />
      )}

      {view === "camera" && (
        <CameraCoach
          capturedPhoto={capturedPhoto}
          setCapturedPhoto={setCapturedPhoto}
          analysis={photoAnalysis}
          loading={photoLoading}
          error={photoError}
          step={coachStep}
          setStep={setCoachStep}
          onAnalyze={analyzeCapturedPhoto}
          coachMode={coachMode}
          setCoachMode={setCoachMode}
          angleLabels={ANGLE_LABELS}
          avatarShots={avatarShots}
          avatarAngleIndex={avatarAngleIndex}
          onCaptureAvatarShot={captureAvatarShot}
          onRetakeAvatarShot={retakeAvatarShot}
          avatarSheet={avatarSheet}
          avatarLoading={avatarLoading}
          avatarError={avatarError}
          avatarUseCase={avatarUseCase}
          setAvatarUseCase={setAvatarUseCase}
          onGenerateAvatarSheet={generateAvatarSheet}
          onResetAvatarSheet={resetAvatarSheet}
        />
      )}

      {view === "queue" && (
        <GuardianQueue queue={queue} onReview={runGuardianReview} onManual={manualSetQueueStatus} />
      )}

      {view.startsWith("agent:") && (
        <AgentChat
          agent={AGENTS.find((a) => a.id === view.split(":")[1])}
          messages={chats[view.split(":")[1]] || []}
          status={statuses[view.split(":")[1]] || "idle"}
          pending={!!pending[view.split(":")[1]]}
          autoSpeak={!!autoSpeak[view.split(":")[1]]}
          setAutoSpeak={(v) => setAutoSpeak((p) => ({ ...p, [view.split(":")[1]]: v }))}
          input={input}
          setInput={setInput}
          onSend={(txt) => { sendToAgent(view.split(":")[1], txt); setInput(""); }}
          onSendToGuardian={(content) => sendToGuardianQueue(view.split(":")[1], content)}
          chatEndRef={chatEndRef}
          ttsSettings={ttsSettings}
        />
      )}
    </div>
  );
}

/* ---------------------------------------------------------------
   DASHBOARD VIEW
--------------------------------------------------------------- */

function Dashboard({
  metrics, setMetrics, totalFollowers, newPoint, setNewPoint, addGrowthPoint, statuses, queue, pendingCount, setView, onQuick,
  execBrief, totalRevenue, upcomingCalendar, copyWeeklyReport, reportCopied,
  growthTopic, setGrowthTopic, growthPillar, setGrowthPillar, growthLoading, onGenerateGrowth,
}) {
  return (
    <div>
      {/* command center header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10, marginBottom: 12 }}>
        <p style={{ margin: 0, fontSize: 11, letterSpacing: 1.5, textTransform: "uppercase", color: COLORS.coral }}>Command center &middot; live report</p>
        <button onClick={copyWeeklyReport} style={{ display: "flex", alignItems: "center", gap: 6, background: "transparent", border: `1px solid ${COLORS.teal}`, color: COLORS.teal, borderRadius: 8, padding: "6px 12px", fontSize: 11.5, cursor: "pointer" }}>
          {reportCopied ? <Check size={12} /> : <Send size={12} />} {reportCopied ? "Copied" : "Copy weekly report"}
        </button>
      </div>

      {/* metrics row */}
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 14 }}>
        <MetricCard label="Total followers" value={totalFollowers.toLocaleString()} accent={COLORS.pink} />
        <MetricCard label="Engagement rate" value={`${metrics.engagementRate}%`} accent={COLORS.teal} />
        <MetricCard label="Revenue tracked" value={`$${totalRevenue.toLocaleString()}`} accent={COLORS.green} />
        <MetricCard label="Awaiting Guardian" value={pendingCount} accent={COLORS.yellow} />
      </div>

      {/* live identity block */}
      <div style={{ background: "#141414", border: `1px solid ${COLORS.teal}44`, borderRadius: 14, padding: 16, marginBottom: 14, display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 10 }}>
        <div>
          <p style={{ margin: 0, fontSize: 15, fontFamily: "'Tektur', sans-serif", color: COLORS.teal }}>{metrics.handle}</p>
          <p style={{ margin: "6px 0 0", fontSize: 12, color: "#A7A1B8", maxWidth: 480 }}>{metrics.bio}</p>
        </div>
        <div style={{ textAlign: "right" }}>
          <span style={{ fontSize: 10.5, color: COLORS.green, border: `1px solid ${COLORS.green}55`, borderRadius: 20, padding: "3px 10px" }}>
            Instagram live via Zapier
          </span>
          <p style={{ margin: "6px 0 0", fontSize: 10.5, color: "#A7A1B8" }}>Last synced {metrics.lastSynced}</p>
        </div>
      </div>

      {/* command row: exec brief + upcoming content + growth engine quick launch */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 12, marginBottom: 14 }}>
        <div style={{ background: "#141414", border: "1px solid #A7A1B833", borderRadius: 14, padding: 14 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <p style={{ margin: 0, fontSize: 11, letterSpacing: 1, textTransform: "uppercase", color: "#A7A1B8" }}>Top priorities</p>
            <button onClick={() => setView("overview")} style={{ background: "none", border: "none", color: COLORS.teal, fontSize: 10.5, cursor: "pointer" }}>Edit &rarr;</button>
          </div>
          {execBrief.priorities.filter(Boolean).length === 0 ? (
            <p style={{ fontSize: 12, color: "#A7A1B8" }}>None set yet.</p>
          ) : (
            <ol style={{ margin: 0, paddingLeft: 18, fontSize: 12, color: "#F5F2FA" }}>
              {execBrief.priorities.filter(Boolean).map((p, i) => <li key={i} style={{ marginBottom: 4 }}>{p}</li>)}
            </ol>
          )}
        </div>

        <div style={{ background: "#141414", border: "1px solid #A7A1B833", borderRadius: 14, padding: 14 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <p style={{ margin: 0, fontSize: 11, letterSpacing: 1, textTransform: "uppercase", color: "#A7A1B8" }}>Upcoming content</p>
            <button onClick={() => setView("overview")} style={{ background: "none", border: "none", color: COLORS.teal, fontSize: 10.5, cursor: "pointer" }}>View all &rarr;</button>
          </div>
          {upcomingCalendar.length === 0 ? (
            <p style={{ fontSize: 12, color: "#A7A1B8" }}>Nothing scheduled yet.</p>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {upcomingCalendar.slice(0, 3).map((e) => (
                <div key={e.id} style={{ fontSize: 12, color: "#F5F2FA", display: "flex", justifyContent: "space-between" }}>
                  <span>{e.date} &middot; {e.platform} &middot; {e.title}</span>
                  <span style={{ color: STATUS_COLORS[e.status === "posted" ? "approved" : "idle"], fontSize: 10.5 }}>{e.status}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div style={{ background: "#141414", border: `1px solid ${COLORS.coral}44`, borderRadius: 14, padding: 14 }}>
          <p style={{ margin: "0 0 8px", fontSize: 11, letterSpacing: 1, textTransform: "uppercase", color: "#A7A1B8" }}>Growth engine -- quick launch</p>
          <input
            placeholder="Topic..."
            value={growthTopic}
            onChange={(e) => setGrowthTopic(e.target.value)}
            style={{ width: "100%", marginBottom: 6 }}
          />
          <div style={{ display: "flex", gap: 6 }}>
            <select value={growthPillar} onChange={(e) => setGrowthPillar(e.target.value)} style={{ flex: 1, background: "#000000", border: "1px solid #A7A1B833", color: "#F5F2FA", borderRadius: 8, padding: "6px 8px", fontSize: 11.5 }}>
              {PILLAR_OPTIONS.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
            <button
              onClick={() => { onGenerateGrowth(); setView("growth"); }}
              disabled={growthLoading || !growthTopic.trim()}
              style={{ display: "flex", alignItems: "center", gap: 5, background: COLORS.coral, border: "none", color: "#000000", fontWeight: 700, borderRadius: 8, padding: "6px 12px", fontSize: 11.5, cursor: "pointer" }}
            >
              {growthLoading ? <Loader2 size={12} className="spin" /> : <TrendingUp size={12} />} Go
            </button>
          </div>
        </div>
      </div>

      {/* platform breakdown + edit */}
      <div style={{ background: "#141414", border: "1px solid #A7A1B833", borderRadius: 14, padding: 16, marginBottom: 14 }}>
        <p style={{ margin: "0 0 10px", fontSize: 12, letterSpacing: 1, textTransform: "uppercase", color: "#A7A1B8" }}>
          Platform snapshot -- Instagram is live-synced, other platforms are manual entry
        </p>
        <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
          {Object.entries(metrics.followers).map(([platform, val]) => (
            <label key={platform} style={{ fontSize: 12, color: "#A7A1B8", display: "flex", flexDirection: "column", gap: 4 }}>
              {platform}
              <input
                type="number"
                value={val}
                onChange={(e) =>
                  setMetrics((m) => ({ ...m, followers: { ...m.followers, [platform]: Number(e.target.value) } }))
                }
                style={{ width: 100 }}
              />
            </label>
          ))}
        </div>
      </div>

      {/* growth chart */}
      <div style={{ background: "#141414", border: "1px solid #A7A1B833", borderRadius: 14, padding: 16, marginBottom: 18 }}>
        <p style={{ margin: "0 0 10px", fontSize: 12, letterSpacing: 1, textTransform: "uppercase", color: "#A7A1B8" }}>Growth over time</p>
        <div style={{ width: "100%", height: 220 }}>
          <ResponsiveContainer>
            <LineChart data={metrics.growthHistory}>
              <CartesianGrid stroke="#A7A1B822" strokeDasharray="4 4" />
              <XAxis dataKey="date" stroke="#A7A1B8" fontSize={11} />
              <YAxis stroke="#A7A1B8" fontSize={11} />
              <Tooltip contentStyle={{ background: "#000000", border: "1px solid #A7A1B833", fontSize: 12 }} labelStyle={{ color: "#F5F2FA" }} />
              <Line type="monotone" dataKey="followers" stroke={COLORS.teal} strokeWidth={2} dot={{ fill: COLORS.pink, r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 10, alignItems: "center", flexWrap: "wrap" }}>
          <input placeholder="Date e.g. Jul 20" value={newPoint.date} onChange={(e) => setNewPoint((p) => ({ ...p, date: e.target.value }))} style={{ width: 120 }} />
          <input placeholder="Total followers" type="number" value={newPoint.followers} onChange={(e) => setNewPoint((p) => ({ ...p, followers: e.target.value }))} style={{ width: 130 }} />
          <button onClick={addGrowthPoint} style={{ display: "flex", alignItems: "center", gap: 5, background: "transparent", border: `1px solid ${COLORS.teal}`, color: COLORS.teal, borderRadius: 8, padding: "7px 12px", fontSize: 12, cursor: "pointer" }}>
            <PlusCircle size={13} /> Add data point
          </button>
        </div>
      </div>

      {/* recent posts, real data */}
      <div style={{ background: "#141414", border: "1px solid #A7A1B833", borderRadius: 14, padding: 16, marginBottom: 18 }}>
        <p style={{ margin: "0 0 10px", fontSize: 12, letterSpacing: 1, textTransform: "uppercase", color: "#A7A1B8" }}>Recent posts -- live from Instagram</p>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
          <thead>
            <tr style={{ color: "#A7A1B8", textAlign: "left" }}>
              <th style={{ padding: "4px 6px", fontWeight: 500 }}>Date</th>
              <th style={{ padding: "4px 6px", fontWeight: 500 }}>Likes</th>
              <th style={{ padding: "4px 6px", fontWeight: 500 }}>Comments</th>
            </tr>
          </thead>
          <tbody>
            {(metrics.recentPosts || []).map((p, i) => (
              <tr key={i} style={{ borderTop: "1px solid #A7A1B822" }}>
                <td style={{ padding: "6px", color: "#F5F2FA" }}>{p.date}</td>
                <td style={{ padding: "6px", color: COLORS.pink }}>{p.likes}</td>
                <td style={{ padding: "6px", color: COLORS.teal }}>{p.comments}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* agent pipeline overview */}
      <p style={{ margin: "0 0 10px", fontSize: 12, letterSpacing: 1, textTransform: "uppercase", color: "#A7A1B8" }}>Agent pipeline</p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))", gap: 12 }}>
        {AGENTS.map((agent) => (
          <div key={agent.id} style={{ background: "#141414", border: `1px solid ${agent.color}33`, borderRadius: 14, padding: 14 }}>
            <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
              <AgentRing agent={agent} size={38} />
              <div style={{ flex: 1 }}>
                <p style={{ margin: 0, fontFamily: "'Tektur', sans-serif", fontSize: 14, color: agent.color }}>{agent.name}</p>
                <p style={{ margin: 0, fontSize: 11, color: "#A7A1B8" }}>{agent.role}</p>
              </div>
            </div>
            <div style={{ marginTop: 8 }}>
              <StatusBadge status={statuses[agent.id] || "idle"} />
            </div>
            <PipelineStepper status={statuses[agent.id] || "idle"} />
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 10 }}>
              {agent.quickActions.slice(0, 2).map((qa) => (
                <button
                  key={qa.label}
                  onClick={() => onQuick(agent.id, qa.prompt)}
                  style={{ fontSize: 10.5, background: "transparent", border: `1px solid ${agent.color}55`, color: agent.color, borderRadius: 7, padding: "5px 8px", cursor: "pointer" }}
                >
                  {qa.label}
                </button>
              ))}
              <button
                onClick={() => setView(`agent:${agent.id}`)}
                style={{ fontSize: 10.5, background: agent.color, border: "none", color: "#000000", fontWeight: 700, borderRadius: 7, padding: "5px 10px", cursor: "pointer" }}
              >
                Chat &rarr;
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   BUSINESS OVERVIEW -- clean, partner/investor-facing view
--------------------------------------------------------------- */

function BusinessOverview({
  metrics, totalFollowers, execBrief, setExecBrief,
  revenue, totalRevenue, addRevenueEntry, deleteRevenueEntry,
  calendar, addCalendarEntry, updateCalendarEntry, deleteCalendarEntry,
  copyWeeklyReport, reportCopied,
}) {
  const [revForm, setRevForm] = useState({ product: "", amount: "", date: "" });
  const [calForm, setCalForm] = useState({ date: "", platform: "Instagram", title: "" });
  const cardStyle = { background: "#141414", border: "1px solid #A7A1B833", borderRadius: 14, padding: 16, marginBottom: 14 };
  const labelStyle = { margin: "0 0 10px", fontSize: 12, letterSpacing: 1, textTransform: "uppercase", color: "#A7A1B8" };

  return (
    <div>
      {/* header + export */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10, marginBottom: 14 }}>
        <div>
          <p style={{ margin: 0, fontFamily: "'Tektur', sans-serif", fontSize: 18, color: "#F5F2FA" }}>Business Overview</p>
          <p style={{ margin: "2px 0 0", fontSize: 11, color: "#A7A1B8" }}>{metrics.handle} &middot; last synced {metrics.lastSynced}</p>
        </div>
        <button onClick={copyWeeklyReport} style={{ display: "flex", alignItems: "center", gap: 6, background: COLORS.teal, border: "none", color: "#000000", fontWeight: 700, borderRadius: 10, padding: "8px 14px", fontSize: 12, cursor: "pointer" }}>
          {reportCopied ? <Check size={13} /> : <Send size={13} />} {reportCopied ? "Copied" : "Copy weekly report"}
        </button>
      </div>

      {/* KPI row */}
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 14 }}>
        <MetricCard label="Followers" value={totalFollowers.toLocaleString()} accent={COLORS.pink} />
        <MetricCard label="Engagement rate" value={`${metrics.engagementRate}%`} accent={COLORS.teal} />
        <MetricCard label="Revenue tracked" value={`$${totalRevenue.toLocaleString()}`} accent={COLORS.green} />
        <MetricCard label="Posts live" value={calendar.filter((c) => c.status === "posted").length} accent={COLORS.purple} />
      </div>

      {/* executive brief */}
      <div style={cardStyle}>
        <p style={labelStyle}>Executive brief</p>
        <p style={{ fontSize: 11, color: "#A7A1B8", margin: "0 0 8px" }}>Top priorities</p>
        {execBrief.priorities.map((p, i) => (
          <input
            key={i}
            value={p}
            onChange={(e) => {
              const next = [...execBrief.priorities];
              next[i] = e.target.value;
              setExecBrief((eb) => ({ ...eb, priorities: next }));
            }}
            placeholder={`Priority ${i + 1}`}
            style={{ width: "100%", marginBottom: 6 }}
          />
        ))}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 8 }}>
          <div>
            <p style={{ fontSize: 11, color: "#A7A1B8", margin: "0 0 6px" }}>Risks</p>
            <textarea rows={3} value={execBrief.risks} onChange={(e) => setExecBrief((eb) => ({ ...eb, risks: e.target.value }))} style={{ width: "100%", resize: "vertical" }} />
          </div>
          <div>
            <p style={{ fontSize: 11, color: "#A7A1B8", margin: "0 0 6px" }}>Opportunities</p>
            <textarea rows={3} value={execBrief.opportunities} onChange={(e) => setExecBrief((eb) => ({ ...eb, opportunities: e.target.value }))} style={{ width: "100%", resize: "vertical" }} />
          </div>
        </div>
      </div>

      {/* revenue tracker */}
      <div style={cardStyle}>
        <p style={labelStyle}>Revenue -- prompt packs & products</p>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          <input placeholder="Product" value={revForm.product} onChange={(e) => setRevForm((f) => ({ ...f, product: e.target.value }))} style={{ flex: 1, minWidth: 120 }} />
          <input placeholder="Amount $" type="number" value={revForm.amount} onChange={(e) => setRevForm((f) => ({ ...f, amount: e.target.value }))} style={{ width: 100 }} />
          <input placeholder="Date" value={revForm.date} onChange={(e) => setRevForm((f) => ({ ...f, date: e.target.value }))} style={{ width: 110 }} />
          <button
            onClick={() => { if (!revForm.product || !revForm.amount) return; addRevenueEntry(revForm); setRevForm({ product: "", amount: "", date: "" }); }}
            style={{ display: "flex", alignItems: "center", gap: 5, background: "transparent", border: `1px solid ${COLORS.green}`, color: COLORS.green, borderRadius: 8, padding: "7px 12px", fontSize: 12, cursor: "pointer" }}
          >
            <PlusCircle size={13} /> Log sale
          </button>
        </div>
        {revenue.entries.length === 0 ? (
          <p style={{ fontSize: 12, color: "#A7A1B8" }}>No sales logged yet.</p>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
            <tbody>
              {revenue.entries.map((e) => (
                <tr key={e.id} style={{ borderTop: "1px solid #A7A1B822" }}>
                  <td style={{ padding: "6px", color: "#F5F2FA" }}>{e.product}</td>
                  <td style={{ padding: "6px", color: COLORS.green }}>${Number(e.amount).toLocaleString()}</td>
                  <td style={{ padding: "6px", color: "#A7A1B8" }}>{e.date}</td>
                  <td style={{ padding: "6px" }}>
                    <button onClick={() => deleteRevenueEntry(e.id)} style={{ background: "none", border: "none", color: "#A7A1B8", cursor: "pointer" }}><X size={13} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* content calendar */}
      <div style={cardStyle}>
        <p style={labelStyle}>Content calendar</p>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          <input placeholder="Date" value={calForm.date} onChange={(e) => setCalForm((f) => ({ ...f, date: e.target.value }))} style={{ width: 110 }} />
          <select value={calForm.platform} onChange={(e) => setCalForm((f) => ({ ...f, platform: e.target.value }))} style={{ background: "#141414", border: "1px solid #A7A1B833", color: "#F5F2FA", borderRadius: 8, padding: "8px 10px" }}>
            {["Instagram", "TikTok", "YouTube", "X", "Newsletter"].map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
          <input placeholder="Title / topic" value={calForm.title} onChange={(e) => setCalForm((f) => ({ ...f, title: e.target.value }))} style={{ flex: 1, minWidth: 140 }} />
          <button
            onClick={() => { if (!calForm.date || !calForm.title) return; addCalendarEntry(calForm); setCalForm({ date: "", platform: "Instagram", title: "" }); }}
            style={{ display: "flex", alignItems: "center", gap: 5, background: "transparent", border: `1px solid ${COLORS.purple}`, color: COLORS.purple, borderRadius: 8, padding: "7px 12px", fontSize: 12, cursor: "pointer" }}
          >
            <PlusCircle size={13} /> Add
          </button>
        </div>
        {calendar.length === 0 ? (
          <p style={{ fontSize: 12, color: "#A7A1B8" }}>Nothing scheduled yet.</p>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
            <tbody>
              {calendar.map((e) => (
                <tr key={e.id} style={{ borderTop: "1px solid #A7A1B822" }}>
                  <td style={{ padding: "6px", color: "#A7A1B8", whiteSpace: "nowrap" }}>{e.date}</td>
                  <td style={{ padding: "6px", color: COLORS.teal }}>{e.platform}</td>
                  <td style={{ padding: "6px", color: "#F5F2FA" }}>{e.title}</td>
                  <td style={{ padding: "6px" }}>
                    <select
                      value={e.status}
                      onChange={(ev) => updateCalendarEntry(e.id, { status: ev.target.value })}
                      style={{ background: "#000000", border: "1px solid #A7A1B833", color: STATUS_COLORS[e.status === "posted" ? "approved" : "idle"], borderRadius: 6, padding: "3px 6px", fontSize: 11 }}
                    >
                      {["planned", "drafted", "scheduled", "posted"].map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </td>
                  <td style={{ padding: "6px" }}>
                    <button onClick={() => deleteCalendarEntry(e.id)} style={{ background: "none", border: "none", color: "#A7A1B8", cursor: "pointer" }}><X size={13} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   GROWTH ENGINE -- batch content generation, organic strategies only
--------------------------------------------------------------- */

const PILLAR_OPTIONS = ["Retro-Cyber", "Neon Kitty", "Tech-Sexy-Nerd", "Fun & Flirty", "Innovative", "Loud", "Artistic/Creative", "Vibrant/Colorful", "Passionate/Driven", "Deep & Thoughtful"];

const GROWTH_PLAYBOOK = [
  { title: "Hook-first, always", body: "Every piece opens with a pattern interrupt or an open loop question in the first 1-2 seconds. No logo intros eating the hook." },
  { title: "Atomize one idea into many formats", body: "One topic becomes a video hook, a carousel, a caption, and a platform-specific post -- instead of one post per idea." },
  { title: "Ride real trends, on-brand", body: "Reskin genuinely trending sounds/formats with MetaKittyz hooks -- never force a trend that doesn't fit the voice." },
  { title: "Test hooks, not whole scripts", body: "Keep the body identical across variants and only change the opening line, so you know what's actually driving watch time." },
  { title: "Consistent cadence beats bursts", body: "Steady daily posting outperforms sporadic high-volume dumps -- algorithms reward predictability." },
  { title: "Repurpose relentlessly", body: "Every flagship piece gets a short-form cut, a caption version, and a text/thread version -- one shoot, many posts." },
];

function GrowthEngine({ topic, setTopic, pillar, setPillar, batch, loading, error, onGenerate, onSendToGuardian }) {
  return (
    <div>
      <div style={{ background: "#141414", border: "1px solid #A7A1B833", borderRadius: 14, padding: 16, marginBottom: 14 }}>
        <p style={{ margin: "0 0 4px", fontFamily: "'Tektur', sans-serif", fontSize: 15, color: COLORS.coral }}>Growth Engine</p>
        <p style={{ margin: "0 0 14px", fontSize: 12, color: "#A7A1B8" }}>
          One topic in, a full batch of on-brand content out -- atomized across formats. Organic and platform-compliant only.
        </p>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          <input
            placeholder="Topic e.g. 'AI agents that never sleep'"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            style={{ flex: 1, minWidth: 220 }}
          />
          <select value={pillar} onChange={(e) => setPillar(e.target.value)} style={{ background: "#141414", border: "1px solid #A7A1B833", color: "#F5F2FA", borderRadius: 8, padding: "8px 10px" }}>
            {PILLAR_OPTIONS.map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
          <button
            onClick={onGenerate}
            disabled={loading || !topic.trim()}
            style={{ display: "flex", alignItems: "center", gap: 6, background: COLORS.coral, border: "none", color: "#000000", fontWeight: 700, borderRadius: 8, padding: "8px 16px", fontSize: 12, cursor: "pointer" }}
          >
            {loading ? <Loader2 size={14} className="spin" /> : <TrendingUp size={14} />} {loading ? "Generating..." : "Generate batch"}
          </button>
        </div>
        {error && <p style={{ fontSize: 12, color: COLORS.coral }}>{error}</p>}

        {batch.length > 0 && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 10, marginTop: 6 }}>
            {batch.map((item, i) => (
              <div key={i} style={{ background: "#000000", border: "1px solid #A7A1B833", borderRadius: 10, padding: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <span style={{ fontSize: 10.5, color: COLORS.teal, textTransform: "uppercase", letterSpacing: 0.5 }}>{item.format}</span>
                  <span style={{ fontSize: 10.5, color: "#A7A1B8" }}>{item.platform}</span>
                </div>
                <p style={{ fontSize: 12.5, color: "#F5F2FA", whiteSpace: "pre-wrap", margin: "0 0 8px" }}>{item.content}</p>
                {(item.trend_stage || item.psychology_driver) && (
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 8 }}>
                    {item.trend_stage && (
                      <span style={{ fontSize: 10, color: COLORS.coral, border: `1px solid ${COLORS.coral}44`, borderRadius: 6, padding: "2px 6px" }}>
                        {item.trend_stage}
                      </span>
                    )}
                    {item.psychology_driver && (
                      <span style={{ fontSize: 10, color: "#A7A1B8" }}>{item.psychology_driver}</span>
                    )}
                  </div>
                )}
                <button onClick={() => onSendToGuardian(item.content)} style={{ fontSize: 10.5, color: COLORS.yellow, background: "none", border: `1px solid ${COLORS.yellow}44`, borderRadius: 6, padding: "3px 8px", cursor: "pointer" }}>
                  Send to Guardian
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={{ background: "#141414", border: "1px solid #A7A1B833", borderRadius: 14, padding: 16 }}>
        <p style={{ margin: "0 0 10px", fontSize: 12, letterSpacing: 1, textTransform: "uppercase", color: "#A7A1B8" }}>Organic growth playbook</p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 10 }}>
          {GROWTH_PLAYBOOK.map((p) => (
            <div key={p.title} style={{ background: "#000000", border: "1px solid #A7A1B833", borderRadius: 10, padding: 12 }}>
              <p style={{ margin: "0 0 4px", fontSize: 12.5, color: COLORS.coral, fontWeight: 700 }}>{p.title}</p>
              <p style={{ margin: 0, fontSize: 11.5, color: "#A7A1B8" }}>{p.body}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   CONTENT STUDIO -- creative brief generator + virality/retention estimates
--------------------------------------------------------------- */

function ScoreBar({ label, data }) {
  if (!data) return null;
  const score = Number(data.score) || 0;
  const color = score >= 70 ? COLORS.green : score >= 40 ? COLORS.yellow : COLORS.coral;
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
        <span style={{ fontSize: 11.5, color: "#A7A1B8" }}>{label}</span>
        <span style={{ fontSize: 11.5, color, fontWeight: 700 }}>{score}/100 &middot; {data.confidence || "?"} confidence</span>
      </div>
      <div style={{ background: "#000000", borderRadius: 20, height: 6, overflow: "hidden" }}>
        <div style={{ width: `${Math.min(100, Math.max(0, score))}%`, background: color, height: "100%" }} />
      </div>
      {(data.explanation || data.notes) && <p style={{ margin: "3px 0 0", fontSize: 10.5, color: "#A7A1B8" }}>{data.explanation || data.notes}</p>}
    </div>
  );
}

function ContentStudio({ topic, setTopic, brief, loading, error, onGenerate, onSendToGuardian }) {
  const cardStyle = { background: "#141414", border: "1px solid #A7A1B833", borderRadius: 14, padding: 16, marginBottom: 14 };
  const labelStyle = { margin: "0 0 8px", fontSize: 11, letterSpacing: 1, textTransform: "uppercase", color: "#A7A1B8" };

  return (
    <div>
      <div style={cardStyle}>
        <p style={{ margin: "0 0 4px", fontFamily: "'Tektur', sans-serif", fontSize: 15, color: COLORS.purple }}>Content Studio</p>
        <p style={{ margin: "0 0 14px", fontSize: 12, color: "#A7A1B8" }}>
          One topic in, a full creative brief out -- hook, script, shot list, filming/editing notes, and an honest, hedged
          virality read. Scores are creative-director estimates, not measured analytics.
        </p>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <input
            placeholder="Topic e.g. 'why my AI agents review each other'"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            style={{ flex: 1, minWidth: 240 }}
          />
          <button
            onClick={onGenerate}
            disabled={loading || !topic.trim()}
            style={{ display: "flex", alignItems: "center", gap: 6, background: COLORS.purple, border: "none", color: "#F5F2FA", fontWeight: 700, borderRadius: 8, padding: "8px 16px", fontSize: 12, cursor: "pointer" }}
          >
            {loading ? <Loader2 size={14} className="spin" /> : <Film size={14} />} {loading ? "Directing..." : "Generate brief"}
          </button>
        </div>
        {error && <p style={{ fontSize: 12, color: COLORS.coral, marginTop: 8 }}>{error}</p>}
      </div>

      {brief && (
        <>
          <div style={cardStyle}>
            <p style={labelStyle}>{brief.title || "Untitled"}</p>
            {brief.hook && <p style={{ fontSize: 13, color: "#F5F2FA", marginBottom: 8 }}><b style={{ color: COLORS.pink }}>Hook:</b> {brief.hook}</p>}
            {brief.why_it_works && <p style={{ fontSize: 12, color: "#A7A1B8", marginBottom: 8 }}><i>{brief.why_it_works}</i></p>}
            <div style={{ display: "flex", gap: 14, flexWrap: "wrap", fontSize: 11.5, color: "#A7A1B8", marginBottom: 10 }}>
              {brief.target_audience && <span><b>Audience:</b> {brief.target_audience}</span>}
              {brief.primary_emotion && <span><b>Emotion:</b> {brief.primary_emotion}</span>}
            </div>
            {brief.script && (
              <div style={{ background: "#000000", border: "1px solid #A7A1B833", borderRadius: 10, padding: 12, marginBottom: 8 }}>
                <p style={{ margin: "0 0 6px", fontSize: 11, color: COLORS.teal, textTransform: "uppercase" }}>Script</p>
                <p style={{ margin: 0, fontSize: 12.5, color: "#F5F2FA", whiteSpace: "pre-wrap" }}>{brief.script}</p>
              </div>
            )}
            {brief.script && (
              <button onClick={() => onSendToGuardian(brief.script)} style={{ fontSize: 10.5, color: COLORS.yellow, background: "none", border: `1px solid ${COLORS.yellow}44`, borderRadius: 6, padding: "3px 8px", cursor: "pointer" }}>
                Send script to Guardian
              </button>
            )}
          </div>

          {Array.isArray(brief.shot_list) && brief.shot_list.length > 0 && (
            <div style={cardStyle}>
              <p style={labelStyle}>Shot list</p>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {brief.shot_list.map((s, i) => (
                  <div key={i} style={{ fontSize: 12, color: "#F5F2FA", display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <span style={{ color: COLORS.purple, fontWeight: 700, minWidth: 60 }}>{s.shot || `Shot ${i + 1}`}</span>
                    <span style={{ color: COLORS.teal }}>{s.type}</span>
                    <span>{s.notes}</span>
                    {s.duration && <span style={{ color: "#A7A1B8" }}>({s.duration})</span>}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 12 }}>
            {(brief.filming_notes || brief.editing_notes) && (
              <div style={cardStyle}>
                <p style={labelStyle}>Filming & editing notes</p>
                {brief.filming_notes && <p style={{ fontSize: 12, color: "#F5F2FA", marginBottom: 6 }}><b>Filming:</b> {brief.filming_notes}</p>}
                {brief.editing_notes && <p style={{ fontSize: 12, color: "#F5F2FA" }}><b>Editing:</b> {brief.editing_notes}</p>}
              </div>
            )}
            {(brief.thumbnail_concept || brief.music_style || brief.cta) && (
              <div style={cardStyle}>
                <p style={labelStyle}>Production details</p>
                {brief.thumbnail_concept && <p style={{ fontSize: 12, color: "#F5F2FA", marginBottom: 6 }}><b>Thumbnail:</b> {brief.thumbnail_concept}</p>}
                {brief.music_style && <p style={{ fontSize: 12, color: "#F5F2FA", marginBottom: 6 }}><b>Music:</b> {brief.music_style}</p>}
                {brief.cta && <p style={{ fontSize: 12, color: "#F5F2FA" }}><b>CTA:</b> {brief.cta}</p>}
              </div>
            )}
          </div>

          {(Array.isArray(brief.alt_hooks) || Array.isArray(brief.alt_titles)) && (
            <div style={cardStyle}>
              <p style={labelStyle}>Alternatives</p>
              {Array.isArray(brief.alt_hooks) && brief.alt_hooks.length > 0 && (
                <div style={{ marginBottom: 8 }}>
                  <p style={{ fontSize: 11, color: "#A7A1B8", margin: "0 0 4px" }}>Alt hooks</p>
                  {brief.alt_hooks.map((h, i) => <p key={i} style={{ fontSize: 12, color: "#F5F2FA", margin: "0 0 3px" }}>&bull; {h}</p>)}
                </div>
              )}
              {Array.isArray(brief.alt_titles) && brief.alt_titles.length > 0 && (
                <div>
                  <p style={{ fontSize: 11, color: "#A7A1B8", margin: "0 0 4px" }}>Alt titles</p>
                  {brief.alt_titles.map((t, i) => <p key={i} style={{ fontSize: 12, color: "#F5F2FA", margin: "0 0 3px" }}>&bull; {t}</p>)}
                </div>
              )}
            </div>
          )}

          {brief.repurposing_plan && (
            <div style={cardStyle}>
              <p style={labelStyle}>Repurposing plan</p>
              <p style={{ fontSize: 12, color: "#F5F2FA" }}>{brief.repurposing_plan}</p>
            </div>
          )}

          {brief.virality_scores && (
            <div style={cardStyle}>
              <p style={labelStyle}>Virality read (creative-director estimate, not measured data)</p>
              {Object.entries(brief.virality_scores).map(([key, data]) => (
                <ScoreBar key={key} label={key.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase())} data={data} />
              ))}
            </div>
          )}

          {Array.isArray(brief.retention_prediction) && brief.retention_prediction.length > 0 && (
            <div style={cardStyle}>
              <p style={labelStyle}>Predicted retention curve (estimate, not measured data)</p>
              <div style={{ width: "100%", height: 180 }}>
                <ResponsiveContainer>
                  <LineChart data={brief.retention_prediction}>
                    <CartesianGrid stroke="#A7A1B822" strokeDasharray="4 4" />
                    <XAxis dataKey="second" stroke="#A7A1B8" fontSize={11} unit="s" />
                    <YAxis stroke="#A7A1B8" fontSize={11} unit="%" domain={[0, 100]} />
                    <Tooltip contentStyle={{ background: "#000000", border: "1px solid #A7A1B833", fontSize: 12 }} labelStyle={{ color: "#F5F2FA" }} />
                    <Line type="monotone" dataKey="percent" stroke={COLORS.purple} strokeWidth={2} dot={{ fill: COLORS.pink, r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------
   PHOTO & VIDEO COACH -- live camera, capture, step-by-step AI coaching
--------------------------------------------------------------- */

const COACH_STEPS = [
  { n: 1, title: "Set the scene", body: "Find good light facing you (window light or a lamp in front, not behind). Keep the background dark and uncluttered -- true black reads best on-brand. Clear your frame of anything distracting." },
  { n: 2, title: "Frame yourself", body: "Turn on your camera below. Use the grid overlay -- put your eyes near the top third line, leave a little headroom, and center yourself left-to-right." },
  { n: 3, title: "Capture", body: "When your framing and lighting look right, hit Capture. Bring energy -- a real expression, not a flat stare -- right before you click." },
  { n: 4, title: "Get coached", body: "Your photo gets analyzed against the MetaKittyz brand identity -- lighting, framing, energy, and brand fit -- with one clear thing to fix." },
];

/* ---------------------------------------------------------------
   LIVE CAMERA -- shared device detection, permission request,
   live preview with grid overlay, capture, and upload fallback
--------------------------------------------------------------- */

function LiveCamera({ onCapture, guideLabel }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const fileInputRef = useRef(null);
  const [cameraOn, setCameraOn] = useState(false);
  const [cameraError, setCameraError] = useState("");
  const [devices, setDevices] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState("");
  const [facingMode, setFacingMode] = useState("user");
  const [supported, setSupported] = useState(true);

  useEffect(() => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setSupported(false);
    }
    return () => stopCamera();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const detectDevices = async () => {
    try {
      const all = await navigator.mediaDevices.enumerateDevices();
      const cams = all.filter((d) => d.kind === "videoinput");
      setDevices(cams);
      if (cams.length && !selectedDeviceId) setSelectedDeviceId(cams[0].deviceId);
    } catch (e) {
      // enumeration failing isn't fatal -- facingMode fallback still works
    }
  };

  const startCamera = async (opts = {}) => {
    setCameraError("");
    try {
      const constraints = {
        audio: false,
        video: opts.deviceId
          ? { deviceId: { exact: opts.deviceId } }
          : { facingMode: opts.facingMode || facingMode },
      };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setCameraOn(true);
      await detectDevices(); // device labels only populate after permission is granted
    } catch (e) {
      setCameraOn(false);
      if (e && e.name === "NotAllowedError") {
        setCameraError("Camera permission was denied. Allow camera access for this tab in your browser's site settings, then try again -- or upload a photo instead below.");
      } else if (e && e.name === "NotFoundError") {
        setCameraError("No camera was detected on this device. Upload a photo instead below.");
      } else {
        setCameraError("Couldn't access the camera -- another app may be using it, or this browser/tab may be blocking camera access. Upload a photo instead below.");
      }
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraOn(false);
  };

  const switchCamera = () => {
    const next = facingMode === "user" ? "environment" : "user";
    setFacingMode(next);
    startCamera({ facingMode: next });
  };

  const handleDeviceChange = (deviceId) => {
    setSelectedDeviceId(deviceId);
    startCamera({ deviceId });
  };

  const capture = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    onCapture(canvas.toDataURL("image/jpeg", 0.88));
  };

  const handleFileUpload = (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => onCapture(reader.result);
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  if (!supported) {
    return (
      <div>
        <p style={{ fontSize: 12, color: COLORS.red, marginBottom: 10 }}>
          This browser/environment doesn't expose camera access. Upload a photo instead:
        </p>
        <input type="file" accept="image/*" onChange={handleFileUpload} style={{ fontSize: 12 }} />
      </div>
    );
  }

  return (
    <div>
      <div style={{ position: "relative", width: "100%", maxWidth: 480, aspectRatio: "4/3", background: "#000", borderRadius: 10, overflow: "hidden", marginBottom: 10 }}>
        <video ref={videoRef} style={{ width: "100%", height: "100%", objectFit: "cover", display: cameraOn ? "block" : "none" }} muted playsInline autoPlay />
        {cameraOn && (
          <>
            <div style={{ position: "absolute", inset: 0, pointerEvents: "none", display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gridTemplateRows: "1fr 1fr 1fr" }}>
              {Array.from({ length: 9 }).map((_, i) => (
                <div key={i} style={{ border: `1px solid ${COLORS.cyan}55` }} />
              ))}
            </div>
            {guideLabel && (
              <div style={{ position: "absolute", top: 8, left: 8, background: "#00000099", color: COLORS.softWhite, fontSize: 11, padding: "3px 8px", borderRadius: 6 }}>
                {guideLabel}
              </div>
            )}
          </>
        )}
        {!cameraOn && (
          <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: COLORS.mutedLilac, fontSize: 12, textAlign: "center", padding: 12 }}>
            Upload a photo below, or try live camera
          </div>
        )}
      </div>
      <canvas ref={canvasRef} style={{ display: "none" }} />

      {cameraError && <p style={{ fontSize: 11.5, color: COLORS.red, marginBottom: 8, maxWidth: 480 }}>{cameraError}</p>}

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
        <button onClick={() => fileInputRef.current && fileInputRef.current.click()} style={{ display: "flex", alignItems: "center", gap: 6, background: COLORS.pink, border: "none", color: "#000", fontWeight: 700, borderRadius: 8, padding: "8px 16px", fontSize: 12, cursor: "pointer" }}>
          <Camera size={14} /> Upload a photo
        </button>
        <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileUpload} style={{ display: "none" }} />

        {!cameraOn ? (
          <button onClick={() => startCamera()} style={{ display: "flex", alignItems: "center", gap: 6, background: "transparent", border: `1px solid ${COLORS.cyan}55`, color: COLORS.cyan, borderRadius: 8, padding: "8px 14px", fontSize: 11.5, cursor: "pointer" }}>
            Try live camera instead
          </button>
        ) : (
          <>
            <button onClick={capture} style={{ display: "flex", alignItems: "center", gap: 6, background: COLORS.cyan, border: "none", color: "#000", fontWeight: 700, borderRadius: 8, padding: "8px 16px", fontSize: 12, cursor: "pointer" }}>
              <Camera size={14} /> Capture
            </button>
            <button onClick={switchCamera} title="Switch front/back camera" style={{ display: "flex", alignItems: "center", gap: 5, background: "transparent", border: `1px solid ${COLORS.mutedLilac}55`, color: COLORS.mutedLilac, borderRadius: 8, padding: "8px 12px", fontSize: 12, cursor: "pointer" }}>
              <RotateCcw size={13} /> Flip
            </button>
            {devices.length > 1 && (
              <select
                value={selectedDeviceId}
                onChange={(e) => handleDeviceChange(e.target.value)}
                style={{ background: COLORS.panel, border: `1px solid ${COLORS.mutedLilac}44`, color: COLORS.softWhite, borderRadius: 8, padding: "7px 8px", fontSize: 11.5 }}
              >
                {devices.map((d, i) => <option key={d.deviceId} value={d.deviceId}>{d.label || `Camera ${i + 1}`}</option>)}
              </select>
            )}
            <button onClick={stopCamera} style={{ background: "transparent", border: `1px solid ${COLORS.mutedLilac}55`, color: COLORS.mutedLilac, borderRadius: 8, padding: "8px 14px", fontSize: 12, cursor: "pointer" }}>
              Turn off
            </button>
          </>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   MEDIA COACH -- Quick Coach + Avatar Reference Sheet modes
--------------------------------------------------------------- */

function CameraCoach({
  capturedPhoto, setCapturedPhoto, analysis, loading, error, step, setStep, onAnalyze,
  coachMode, setCoachMode, angleLabels, avatarShots, avatarAngleIndex, onCaptureAvatarShot, onRetakeAvatarShot,
  avatarSheet, avatarLoading, avatarError, avatarUseCase, setAvatarUseCase, onGenerateAvatarSheet, onResetAvatarSheet,
}) {
  const cardStyle = { background: COLORS.panel, border: `1px solid ${COLORS.mutedLilac}33`, borderRadius: 14, padding: 16, marginBottom: 14 };
  const labelStyle = { margin: "0 0 8px", fontSize: 11, letterSpacing: 1, textTransform: "uppercase", color: COLORS.mutedLilac };
  const [copiedPrompt, setCopiedPrompt] = useState(false);

  const copyVideoPrompt = async () => {
    if (!avatarSheet || !avatarSheet.video_prompt) return;
    try {
      await navigator.clipboard.writeText(avatarSheet.video_prompt);
      setCopiedPrompt(true);
      setTimeout(() => setCopiedPrompt(false), 2000);
    } catch (e) {}
  };

  const retake = () => {
    setCapturedPhoto(null);
    setStep(2);
  };

  return (
    <div>
      <div style={cardStyle}>
        <p style={{ margin: "0 0 4px", fontFamily: "'Tektur', sans-serif", fontSize: 15, color: COLORS.pink }}>Media Coach</p>
        <p style={{ margin: "0 0 8px", fontSize: 12, color: COLORS.mutedLilac }}>
          Upload a photo (or try live camera) to get real coaching against the MetaKittyz brand identity -- or build a
          full multi-angle reference sheet you can hand to a videographer or an AI video tool.
        </p>
        <p style={{ margin: "0 0 12px", fontSize: 11, color: COLORS.mutedLilac }}>
          Privacy note: photos are analyzed in this session only -- never saved to this dashboard's storage. Live
          camera access depends on your browser/device allowing it in this environment -- upload always works.
        </p>
        <div style={{ display: "flex", gap: 8 }}>
          <button
            onClick={() => setCoachMode("quick")}
            style={{ background: coachMode === "quick" ? COLORS.pink : "transparent", border: `1px solid ${COLORS.pink}`, color: coachMode === "quick" ? "#000" : COLORS.pink, fontWeight: 700, borderRadius: 8, padding: "7px 14px", fontSize: 12, cursor: "pointer" }}
          >
            Quick Coach
          </button>
          <button
            onClick={() => setCoachMode("avatar")}
            style={{ background: coachMode === "avatar" ? COLORS.purple : "transparent", border: `1px solid ${COLORS.purple}`, color: coachMode === "avatar" ? "#000" : COLORS.purple, fontWeight: 700, borderRadius: 8, padding: "7px 14px", fontSize: 12, cursor: "pointer" }}
          >
            Avatar Reference Sheet
          </button>
        </div>
      </div>

      {coachMode === "quick" && (
        <>
          <div style={{ display: "flex", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
            {COACH_STEPS.map((s) => (
              <div
                key={s.n}
                onClick={() => (s.n <= 3 ? setStep(s.n) : null)}
                style={{
                  flex: 1, minWidth: 140, cursor: s.n <= 3 ? "pointer" : "default",
                  background: step === s.n ? `${COLORS.pink}22` : COLORS.panel,
                  border: `1px solid ${step === s.n ? COLORS.pink : COLORS.mutedLilac + "33"}`,
                  borderRadius: 10, padding: 10,
                }}
              >
                <p style={{ margin: 0, fontSize: 10.5, color: step === s.n ? COLORS.pink : COLORS.mutedLilac, textTransform: "uppercase", letterSpacing: 0.5 }}>Step {s.n}</p>
                <p style={{ margin: "2px 0 0", fontSize: 12, color: COLORS.softWhite, fontWeight: 700 }}>{s.title}</p>
              </div>
            ))}
          </div>

          <div style={cardStyle}>
            <p style={labelStyle}>{COACH_STEPS[step - 1]?.title}</p>
            <p style={{ fontSize: 12.5, color: COLORS.softWhite, marginBottom: 12 }}>{COACH_STEPS[step - 1]?.body}</p>

            {step <= 3 && !capturedPhoto && (
              <LiveCamera onCapture={(dataUrl) => { setCapturedPhoto(dataUrl); setStep(4); onAnalyze(dataUrl); }} />
            )}

            {capturedPhoto && (
              <div>
                <img src={capturedPhoto} alt="Captured" style={{ width: "100%", maxWidth: 480, borderRadius: 10, marginBottom: 10 }} />
                <button onClick={retake} style={{ display: "flex", alignItems: "center", gap: 6, background: "transparent", border: `1px solid ${COLORS.cyan}`, color: COLORS.cyan, borderRadius: 8, padding: "7px 14px", fontSize: 12, cursor: "pointer" }}>
                  <RotateCcw size={13} /> Retake
                </button>
              </div>
            )}

            {loading && (
              <p style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: COLORS.mutedLilac, marginTop: 10 }}>
                <Loader2 size={13} className="spin" /> Analyzing your photo...
              </p>
            )}
            {error && <p style={{ fontSize: 12, color: COLORS.red, marginTop: 10 }}>{error}</p>}
          </div>

          {analysis && (
            <div style={cardStyle}>
              <p style={labelStyle}>Coaching notes</p>
              {analysis.overall_verdict && (
                <p style={{ fontSize: 13, color: COLORS.softWhite, marginBottom: 10 }}><i>{analysis.overall_verdict}</i></p>
              )}
              {analysis.top_fix && (
                <div style={{ background: `${COLORS.pink}18`, border: `1px solid ${COLORS.pink}55`, borderRadius: 10, padding: 10, marginBottom: 12 }}>
                  <p style={{ margin: 0, fontSize: 11, color: COLORS.pink, textTransform: "uppercase", fontWeight: 700 }}>Top fix</p>
                  <p style={{ margin: "4px 0 0", fontSize: 12.5, color: COLORS.softWhite }}>{analysis.top_fix}</p>
                </div>
              )}
              {["lighting", "framing", "expression_energy", "brand_fit"].map((key) =>
                analysis[key] ? <ScoreBar key={key} label={key.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase())} data={analysis[key]} /> : null
              )}
            </div>
          )}
        </>
      )}

      {coachMode === "avatar" && (
        <>
          <div style={cardStyle}>
            <p style={labelStyle}>Angle progress</p>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 12 }}>
              {angleLabels.map((label, i) => (
                <div key={label} style={{ display: "flex", alignItems: "center", gap: 8, background: avatarShots[label] ? `${COLORS.green}18` : COLORS.panel, border: `1px solid ${avatarShots[label] ? COLORS.green : COLORS.mutedLilac + "33"}`, borderRadius: 10, padding: "6px 10px" }}>
                  {avatarShots[label] ? (
                    <img src={avatarShots[label]} alt={label} style={{ width: 32, height: 32, objectFit: "cover", borderRadius: 6 }} />
                  ) : (
                    <div style={{ width: 32, height: 32, borderRadius: 6, background: "#000", display: "flex", alignItems: "center", justifyContent: "center" }}>
                      <Camera size={14} color={COLORS.mutedLilac} />
                    </div>
                  )}
                  <div>
                    <p style={{ margin: 0, fontSize: 11, color: avatarShots[label] ? COLORS.green : COLORS.mutedLilac }}>{label}</p>
                    {avatarShots[label] && (
                      <button onClick={() => onRetakeAvatarShot(label)} style={{ fontSize: 10, color: COLORS.cyan, background: "none", border: "none", cursor: "pointer", padding: 0 }}>Retake</button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {avatarAngleIndex < angleLabels.length && !avatarShots[angleLabels[avatarAngleIndex]] && (
              <>
                <p style={{ fontSize: 12.5, color: COLORS.softWhite, marginBottom: 10 }}>
                  Now capturing: <b style={{ color: COLORS.purple }}>{angleLabels[avatarAngleIndex]}</b>
                </p>
                <LiveCamera
                  guideLabel={angleLabels[avatarAngleIndex]}
                  onCapture={(dataUrl) => onCaptureAvatarShot(dataUrl, angleLabels[avatarAngleIndex])}
                />
              </>
            )}

            <div style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 14, flexWrap: "wrap" }}>
              <label style={{ fontSize: 11.5, color: COLORS.mutedLilac }}>Primary use case:</label>
              <select value={avatarUseCase} onChange={(e) => setAvatarUseCase(e.target.value)} style={{ background: COLORS.panel, border: `1px solid ${COLORS.mutedLilac}44`, color: COLORS.softWhite, borderRadius: 8, padding: "6px 8px", fontSize: 11.5 }}>
                {["ads", "education", "social/organic"].map((u) => <option key={u} value={u}>{u}</option>)}
              </select>
              <button
                onClick={onGenerateAvatarSheet}
                disabled={avatarLoading || Object.keys(avatarShots).length === 0}
                style={{ display: "flex", alignItems: "center", gap: 6, background: COLORS.purple, border: "none", color: "#000", fontWeight: 700, borderRadius: 8, padding: "8px 16px", fontSize: 12, cursor: "pointer" }}
              >
                {avatarLoading ? <Loader2 size={14} className="spin" /> : <Film size={14} />} {avatarLoading ? "Building sheet..." : "Generate Reference Sheet"}
              </button>
              <button onClick={onResetAvatarSheet} style={{ background: "transparent", border: `1px solid ${COLORS.mutedLilac}55`, color: COLORS.mutedLilac, borderRadius: 8, padding: "8px 12px", fontSize: 11.5, cursor: "pointer" }}>
                Start over
              </button>
            </div>
            {avatarError && <p style={{ fontSize: 12, color: COLORS.red, marginTop: 10 }}>{avatarError}</p>}
          </div>

          {avatarSheet && (
            <>
              {avatarSheet.video_prompt && (
                <div style={cardStyle}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                    <p style={{ ...labelStyle, margin: 0 }}>Ready-to-use video prompt</p>
                    <button onClick={copyVideoPrompt} style={{ display: "flex", alignItems: "center", gap: 5, background: "transparent", border: `1px solid ${COLORS.cyan}`, color: COLORS.cyan, borderRadius: 6, padding: "4px 10px", fontSize: 11, cursor: "pointer" }}>
                      {copiedPrompt ? <Check size={12} /> : <Send size={12} />} {copiedPrompt ? "Copied" : "Copy"}
                    </button>
                  </div>
                  <p style={{ fontSize: 12.5, color: COLORS.softWhite, whiteSpace: "pre-wrap" }}>{avatarSheet.video_prompt}</p>
                </div>
              )}

              {Array.isArray(avatarSheet.angle_notes) && avatarSheet.angle_notes.length > 0 && (
                <div style={cardStyle}>
                  <p style={labelStyle}>Angle notes</p>
                  {avatarSheet.angle_notes.map((a, i) => (
                    <p key={i} style={{ fontSize: 12, color: COLORS.softWhite, marginBottom: 6 }}><b style={{ color: COLORS.purple }}>{a.angle}:</b> {a.notes}</p>
                  ))}
                </div>
              )}

              {Array.isArray(avatarSheet.shot_list) && avatarSheet.shot_list.length > 0 && (
                <div style={cardStyle}>
                  <p style={labelStyle}>Shot list</p>
                  <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                    {avatarSheet.shot_list.map((s, i) => (
                      <div key={i} style={{ fontSize: 12, color: COLORS.softWhite, display: "flex", gap: 8, flexWrap: "wrap" }}>
                        <span style={{ color: COLORS.purple, fontWeight: 700, minWidth: 60 }}>{s.shot || `Shot ${i + 1}`}</span>
                        <span style={{ color: COLORS.cyan }}>{s.type}</span>
                        <span>{s.notes}</span>
                        {s.use_case && <span style={{ color: COLORS.mutedLilac }}>[{s.use_case}]</span>}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div style={cardStyle}>
                {Array.isArray(avatarSheet.recommended_use_cases) && avatarSheet.recommended_use_cases.length > 0 && (
                  <div style={{ marginBottom: avatarSheet.overall_recommendation ? 10 : 0 }}>
                    <p style={labelStyle}>Recommended for</p>
                    <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                      {avatarSheet.recommended_use_cases.map((u, i) => (
                        <span key={i} style={{ fontSize: 11, color: COLORS.green, border: `1px solid ${COLORS.green}55`, borderRadius: 20, padding: "3px 10px" }}>{u}</span>
                      ))}
                    </div>
                  </div>
                )}
                {avatarSheet.overall_recommendation && (
                  <p style={{ fontSize: 13, color: COLORS.softWhite }}><i>{avatarSheet.overall_recommendation}</i></p>
                )}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------
   GUARDIAN QUEUE VIEW
--------------------------------------------------------------- */

function GuardianQueue({ queue, onReview, onManual }) {
  if (queue.length === 0) {
    return (
      <div style={{ textAlign: "center", padding: "50px 10px", color: "#A7A1B8" }}>
        <ShieldCheck size={34} color={COLORS.yellow} style={{ marginBottom: 10 }} />
        <p style={{ fontSize: 14 }}>Nothing waiting on review. Send content here from any agent's chat with "Send to Guardian".</p>
      </div>
    );
  }
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {queue.map((item) => {
        const agent = AGENTS.find((a) => a.id === item.agentId);
        return (
          <div key={item.id} style={{ background: "#141414", border: `1px solid ${(STATUS_COLORS[item.status === "flagged" ? "needs_revision" : item.status] || "#A7A1B8")}44`, borderRadius: 14, padding: 14 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                {agent ? <AgentRing agent={agent} size={28} /> : <TrendingUp size={20} color={COLORS.coral} />}
                <span style={{ fontSize: 12, color: "#A7A1B8" }}>{agent ? agent.name : (item.sourceLabel || "unknown")} &middot; {item.createdAt}</span>
              </div>
              <StatusBadge status={item.status === "flagged" ? "needs_revision" : item.status} />
            </div>
            <p style={{ margin: "10px 0", fontSize: 13, color: "#F5F2FA", whiteSpace: "pre-wrap" }}>{item.content}</p>
            {item.notes && (
              <div style={{ background: "#000000", border: "1px solid #A7A1B833", borderRadius: 10, padding: 10, marginBottom: 8 }}>
                <p style={{ margin: 0, fontSize: 12, color: COLORS.yellow, fontWeight: 700 }}>Guardian notes</p>
                <p style={{ margin: "4px 0 0", fontSize: 12, color: "#A7A1B8" }}>{item.notes}</p>
                {item.issues && item.issues.length > 0 && (
                  <ul style={{ margin: "6px 0 0", paddingLeft: 18, fontSize: 12, color: COLORS.coral }}>
                    {item.issues.map((iss, i) => <li key={i}>{iss}</li>)}
                  </ul>
                )}
              </div>
            )}
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <button onClick={() => onReview(item.id)} disabled={item.reviewing} style={{ display: "flex", alignItems: "center", gap: 5, background: COLORS.yellow, border: "none", color: "#000000", fontWeight: 700, borderRadius: 8, padding: "6px 12px", fontSize: 12, cursor: "pointer" }}>
                {item.reviewing ? <Loader2 size={13} className="spin" /> : <ShieldCheck size={13} />} Run Guardian review
              </button>
              <button onClick={() => onManual(item.id, "approved")} style={{ display: "flex", alignItems: "center", gap: 5, background: "transparent", border: `1px solid ${COLORS.green}`, color: COLORS.green, borderRadius: 8, padding: "6px 12px", fontSize: 12, cursor: "pointer" }}>
                <Check size={13} /> Approve manually
              </button>
              <button onClick={() => onManual(item.id, "flagged")} style={{ display: "flex", alignItems: "center", gap: 5, background: "transparent", border: `1px solid ${COLORS.coral}`, color: COLORS.coral, borderRadius: 8, padding: "6px 12px", fontSize: 12, cursor: "pointer" }}>
                <Flag size={13} /> Flag manually
              </button>
              {item.status === "approved" && (
                <button onClick={() => onManual(item.id, "posted")} style={{ display: "flex", alignItems: "center", gap: 5, background: "transparent", border: `1px solid ${COLORS.teal}`, color: COLORS.teal, borderRadius: 8, padding: "6px 12px", fontSize: 12, cursor: "pointer" }}>
                  <Rocket size={13} /> Mark posted
                </button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ---------------------------------------------------------------
   AGENT CHAT VIEW
--------------------------------------------------------------- */

function AgentChat({ agent, messages, status, pending, autoSpeak, setAutoSpeak, input, setInput, onSend, onSendToGuardian, chatEndRef, ttsSettings }) {
  const [showAgreement, setShowAgreement] = useState(false);
  if (!agent) return null;

  return (
    <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: 16 }}>
      {/* left panel */}
      <div>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
          <AgentRing agent={agent} size={48} />
          <div>
            <p style={{ margin: 0, fontFamily: "'Tektur', sans-serif", color: agent.color, fontSize: 16 }}>{agent.name}</p>
            <p style={{ margin: 0, fontSize: 11, color: "#A7A1B8" }}>{agent.role}</p>
          </div>
        </div>
        <StatusBadge status={status} />
        <PipelineStepper status={status} />

        <button
          onClick={() => setShowAgreement((s) => !s)}
          style={{ display: "flex", alignItems: "center", gap: 5, background: "transparent", border: "1px solid #A7A1B833", color: "#A7A1B8", borderRadius: 8, padding: "6px 10px", fontSize: 11, cursor: "pointer", marginTop: 14, width: "100%", justifyContent: "space-between" }}
        >
          System ruling & guardrails
          {showAgreement ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
        </button>
        {showAgreement && (
          <div style={{ background: "#000000", border: "1px solid #A7A1B833", borderRadius: 10, padding: 10, marginTop: 6, maxHeight: 220, overflowY: "auto" }} className="mkz-scroll">
            <pre style={{ whiteSpace: "pre-wrap", fontSize: 10.5, color: "#A7A1B8", margin: 0, fontFamily: "'Outfit', monospace" }}>{agent.extraRules.trim()}</pre>
          </div>
        )}

        <div style={{ marginTop: 16 }}>
          <p style={{ fontSize: 11, letterSpacing: 1, textTransform: "uppercase", color: "#A7A1B8", marginBottom: 8 }}>Quick actions</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {agent.quickActions.map((qa) => (
              <button
                key={qa.label}
                onClick={() => onSend(qa.prompt)}
                style={{ textAlign: "left", background: "transparent", border: `1px solid ${agent.color}44`, color: agent.color, borderRadius: 8, padding: "8px 10px", fontSize: 12, cursor: "pointer" }}
              >
                {qa.label}
              </button>
            ))}
          </div>
        </div>

        <label style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 16, fontSize: 12, color: "#A7A1B8", cursor: "pointer" }}>
          <input type="checkbox" checked={autoSpeak} onChange={(e) => setAutoSpeak(e.target.checked)} style={{ width: "auto" }} />
          Auto-speak replies (TTS)
        </label>
      </div>

      {/* chat panel */}
      <div style={{ display: "flex", flexDirection: "column", background: "#141414", border: "1px solid #A7A1B833", borderRadius: 14, padding: 14, minHeight: 420 }}>
        <div className="mkz-scroll" style={{ flex: 1, overflowY: "auto", maxHeight: 420, display: "flex", flexDirection: "column", gap: 12, paddingRight: 4 }}>
          {messages.length === 0 && (
            <p style={{ color: "#A7A1B8", fontSize: 12, margin: "auto", textAlign: "center" }}>
              Say hi to {agent.name}, or run a quick action on the left.
            </p>
          )}
          {messages.map((m) => (
            <MessageBubble key={m.id} msg={m} agent={agent} onSendToGuardian={onSendToGuardian} ttsSettings={ttsSettings} />
          ))}
          {pending && (
            <div style={{ display: "flex", alignItems: "center", gap: 6, color: "#A7A1B8", fontSize: 12 }}>
              <Loader2 size={13} className="spin" /> {agent.name} is thinking...
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
          <textarea
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); onSend(input); } }}
            placeholder={`Message ${agent.name}...`}
            style={{ flex: 1, resize: "none" }}
          />
          <button onClick={() => onSend(input)} style={{ background: agent.color, border: "none", color: "#000000", borderRadius: 8, padding: "0 16px", cursor: "pointer", display: "flex", alignItems: "center" }}>
            <Send size={16} />
          </button>
        </div>
      </div>

      <style>{`.spin { animation: mkzspin 1s linear infinite; } @keyframes mkzspin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function MessageBubble({ msg, agent, onSendToGuardian, ttsSettings }) {
  const [showThinking, setShowThinking] = useState(false);
  const isUser = msg.role === "user";
  return (
    <div style={{ alignSelf: isUser ? "flex-end" : "flex-start", maxWidth: "88%" }}>
      <div
        style={{
          background: isUser ? "#A7A1B822" : "#000000",
          border: `1px solid ${isUser ? "#A7A1B844" : agent.color + "44"}`,
          borderRadius: 12,
          padding: "10px 12px",
        }}
      >
        <p style={{ margin: 0, fontSize: 13, whiteSpace: "pre-wrap", color: "#F5F2FA" }}>{msg.content}</p>
      </div>
      {!isUser && (
        <div style={{ display: "flex", gap: 10, marginTop: 5, alignItems: "center", flexWrap: "wrap" }}>
          {msg.thinking && (
            <button onClick={() => setShowThinking((s) => !s)} style={{ fontSize: 10.5, color: "#A7A1B8", background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 3 }}>
              {showThinking ? <ChevronDown size={11} /> : <ChevronRight size={11} />} reasoning
            </button>
          )}
          <button onClick={() => speak(msg.content, ttsSettings)} style={{ fontSize: 10.5, color: "#A7A1B8", background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 3 }}>
            <Volume2 size={11} /> play
          </button>
          {agent.producesContent && (
            <button onClick={() => onSendToGuardian(msg.content)} style={{ fontSize: 10.5, color: COLORS.yellow, background: "none", border: `1px solid ${COLORS.yellow}44`, borderRadius: 6, padding: "2px 7px", cursor: "pointer" }}>
              Send to Guardian
            </button>
          )}
        </div>
      )}
      {showThinking && msg.thinking && (
        <div style={{ background: "#000000", border: "1px dashed #A7A1B844", borderRadius: 8, padding: 8, marginTop: 4 }}>
          <p style={{ margin: 0, fontSize: 10.5, color: "#A7A1B8", whiteSpace: "pre-wrap" }}>{msg.thinking}</p>
        </div>
      )}
    </div>
  );
}
