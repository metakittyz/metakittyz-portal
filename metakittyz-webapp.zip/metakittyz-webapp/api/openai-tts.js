// Vercel serverless function: /api/openai-tts
// OpenAI's API blocks direct browser calls (no CORS headers), so this exists purely
// to relay the request server-to-server, where CORS doesn't apply.
//
// NOTE ON THE KEY: this app uses a "bring your own OpenAI key" model entered in the
// Voice Settings panel -- the key is sent from the browser to this endpoint on each
// request rather than stored as a server env var. That means it's still visible in
// this browser's own Network tab when the request goes out (same as before), it just
// no longer gets blocked by OpenAI's CORS policy. Don't pull this key up on a shared
// screen with dev tools open.

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }

  try {
    const { apiKey, voice, input, instructions } = req.body;
    if (!apiKey) {
      res.status(400).json({ error: "Missing OpenAI API key in request" });
      return;
    }

    const response = await fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini-tts",
        voice: voice || "shimmer",
        input,
        instructions,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      res.status(response.status).json({ error: "OpenAI TTS request failed", detail: errText });
      return;
    }

    const arrayBuffer = await response.arrayBuffer();
    res.setHeader("Content-Type", "audio/mpeg");
    res.status(200).send(Buffer.from(arrayBuffer));
  } catch (err) {
    res.status(500).json({ error: "Proxy request to OpenAI failed", detail: String(err) });
  }
}
